﻿[CmdletBinding()]
param (
    [Parameter()]
    [switch]
    $whatIf
)    

function Get-RandomCharacters($length, $characters) { 
    $random = 1..$length | ForEach-Object { Get-Random -Maximum $characters.length } 
    $private:ofs = "" 
    return [String]$characters[$random]
}

Function Install-ArmTtkModule {
    if(get-module -listavailable -name arm-ttk){
        write-host 'Arm TTK is installed'
    }
    else{
        import-module bitstransfer
        Start-BitsTransfer -Source 'https://aka.ms/arm-ttk-latest' -destination "$env:temp\arm-ttk.zip"
        Expand-Archive -Path "$env:temp\arm-ttk.zip" -DestinationPath "~\Documents\PowerShell\Modules\"
        Push-Location "~\Documents\Powershell\Modules\arm-ttk"
        Get-ChildItem *.ps1, *.psd1, *.ps1xml, *.psm1 -Recurse | Unblock-File
        Import-module arm-ttk
        Pop-Location
    }
}

# Set the RG variables.
$date = Get-Date -UFormat "%Y%m%d-%H%M%S"
$rgName = 'bicepTest'
$rgLocation = 'australiaeast'
$rgDeploymentName = 'StorageAccountDeployment'
$rgTags = @{
    costCenterCode     = '2110214'
    criticality        = 'Low'
    resOwner           = 'Craig Dempsey'
    resOwnerDepartment = 'MSH Architecture & Security'
    resOwnerEmail      = 'craig.dempsey@health.qld.gov.au'
    resOwnerPhone      = '0731769082'
    resOwnerPosition   = 'Senior Technical Architect'
    deploymentMethod   = 'Arm Template'
    system             = 'CIDAS Management'
}
$tempStorTags = @{
    costCenterCode     = '2110214'
    criticality        = 'Low'
    resOwner           = 'Craig Dempsey'
    resOwnerDepartment = 'MSH Architecture & Security'
    resOwnerEmail      = 'craig.dempsey@health.qld.gov.au'
    resOwnerPhone      = '0731769082'
    resOwnerPosition   = 'Senior Technical Architect'
    deploymentMethod   = 'Arm Template'
    system             = 'CIDAS Management'
    transient          = 'true'
}

# Run the bicep build.
bicep build ./main.bicep

# Install the Arm TTK Module if not installed.
Install-ArmTtkModule

# Test-ARM Template against best practices.
Test-AzTemplate -TemplatePath '.\main.json'

# If Statement to carry out a "whatIf" if the parameter is specified.
if ($psboundparameters['whatIf']){
    New-AzResourceGroupDeployment `
    -Name ($rgDeploymentName + $date) `
    -ResourceGroupName $rgName `
    -TemplateFile '.\main.json' `
    -TemplateParameterFile '.\main.parameters.json' `
    -Verbose `
    -whatif

    # Get-AzResourceGroupDeploymentWhatIfResult `
    # -DeploymentName ($rgDeploymentName + $date) `
    # -ResourceGroupName $rgName `
    # -TemplateFile '.\main.json' `
    # -TemplateParameterFile '.\main.parameters.json' `
    # -ResultFormat FullResourcePayloads 
    
}
# If no "whatIf" then do the deployment
else {

    #Set / Create Resource Group
    $rg = New-AzResourceGroup -Name $rgName -Location $rgLocation -Tag $rgTags -Verbose -Force

    #Set the Temporary Storage Account Variables.
    $tempStorageAccountNamePrefix = 'mshcidastempstor'
    $randomSuffix = Get-RandomCharacters -length 5 -characters '0123456789'
    $tempStorageAccountName = $tempStorageAccountNamePrefix + $randomSuffix
    $tempStorageContainerName = 'templates'

    # Create Temporary Deployment Storage Account
    $tempStorAcc = New-AzStorageAccount `
        -Name $tempStorageAccountName `
        -ResourceGroupName $rg.resourceGroupName `
        -Location $rg.location `
        -Type Standard_LRS `
        -Tag $tempStorTags

    # Set Temporary Deployment Storage Account as current Storage Account
    Set-AzCurrentStorageAccount `
        -ResourceGroupName $rg.ResourceGroupName `
        -Name $tempStorAcc.StorageAccountName

    # Create new Storage Container
    New-AzStorageContainer `
        -Name templates `
        -Permission Off

    # Copy the files.
    Write-Verbose 'Standby...Attempting to copy files to Azure Blob Storage.'
    $error.clear()
    try {
        Get-ChildItem -File  -Recurse | Set-AzStorageBlobContent `
        -Container $tempStorageContainerName -ErrorAction Stop      
    }
    catch {
        Write-Error 'An error occurred while trying to copy files to Azure.'
    }
    if(!$error){
        Write-Verbose 'File copy complete.'
    }

    #Get Artifacts Location
    $_artifactsLocation = $tempStorAcc.Context.BlobEndPoint + $tempStorageContainerName 

    $_artifactsLocationSasToken = New-AzStorageContainerSASToken `
        -Container $tempStorageContainerName `
        -Context (get-azstoragecontainer -name templates).Context `
        -Permission r  `
        -ExpiryTime (get-Date).AddHours(5) 

    $_artifactsLocationSasToken = ConvertTo-SecureString -AsPlainText -Force ($_artifactsLocationSasToken) 

    New-AzResourceGroupDeployment `
        -Name ($rgDeploymentName + $date) `
        -ResourceGroupName $rg.ResourceGroupName `
        -TemplateFile '.\main.json' `
        -TemplateParameterFile '.\main.parameters.json' `
        -_artifactsLocation $_artifactsLocation `
        -_artifactsLocationSasToken $_artifactsLocationSasToken `
        -Verbose 
    #    -DeploymentDebugLogLevel All - Used for debugging.
    
    #Delete the Temporary Storage Account.
    Remove-AzStorageAccount `
        -Name $tempStorageContainerName `
        -ResourceGroupName $rg.ResourceGroupName `
        -Force
}

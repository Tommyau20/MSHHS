$operations = Get-AzResourceGroupDeploymentOperation -deploymentname StorageAccountDeployment20201126-064726 -ResourceGroupName bicepTest
foreach($operation in $operations)

{
    Write-Host $operation.id
    Write-Host "Request:"
    $operation.Properties.Request | ConvertTo-Json -Depth 10
    Write-Host "Response:"
    $operation.Properties.Response | ConvertTo-Json -Depth 10
}
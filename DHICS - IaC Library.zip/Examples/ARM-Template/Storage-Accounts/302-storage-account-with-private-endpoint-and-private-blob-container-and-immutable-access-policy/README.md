# Storage Account with Private Endpoint, Private Blob Container and Immutable Access Policy 

This template deploys a Storage Account that aligns with MSH Operations & Security Benchmarks v0.5. 

It has the folllwing features: - 

## Immutable Access Policy
This storage account has an immutable access policy set for use with logging. 
**Warning** You have to lock that immutable access policy in when you are ready. Once it's turned on, you can't change it for the duration of the retention period.

## Networking
In this template, I have set the following by default: - 
-  QH Proxy in the Storage Firewall
   -   to allow traffic to come from the QH Network and go out the QH Internet Gateway to Azure.
- Private Endpoint
  - Setting this will force traffic over our Private Express Route.
  - An extra manual step is needed when setting Private Endpoint. You will have to manually log a job to the eHealth Cloud Services team to set an A Record in their Private DNS Zone for the Private Endpoint that you have created. Due to this limitation, no Private Endpoints in our subscription will be Private DNS Integrated.
- You shouldn't need both of these, choose one and disable the other.

## Advanced Threat Analytics
This template enables Advanced Theat Analytics on this storage account so that Azure Security Center can scan the Storage Account.

## Secure HTTP
This template enables Secure HTTP.

## Logging
This template enables Storage Diagnostic logging via a Powershell Script that runs via the Micrsoft.Resources/DeploymentScripts provider. 

## Private Blob Container
A private Blbo Container has been enabled in this template.

## User Managed Identity
A UMI is used as the authentication mechanism to run the Powershell Script via the Microsoft.Resrouces/DeploymentScripts provider.

## Alignment to MSH Operational & Security Standards
This template deploys a Storage Account that aligns with MSH Operations & Security Benchmarks v0.5. 

## Compliance
3.1.1 - Ensure that 'Secure transfer required' is set to 'Enabled'  
3.1.3 - Ensure that Storage logging is enabled for Queue service for read, write, and delete requests.  
3.1.6 - Ensure that 'Public access level' is set to Private for blob containers.  
3.1.7 - Ensure default network access rule for Sotrage Accounts is set to deny  
3.1.8 - Ensure 'Trusted Microsoft Services' is enabled for Storage Account access.  
3.2.1 - Ensure that Account Kind is set to Storage v2 (general purpsose)  
3.2.2 - Ensure Private Endpoint is setup to allow connectivity from vNet.  
3.2.3 - Ensure Advanced Threat Protection is enabled.  
3.2.4 - Where Storage Accounts are used for logs, make sure the access policy is set to read only, immutable  
3.2.5 - Make sure read only immutable logs have a retention set to 90 days.  
3.2.6 - Make sure Blob soft delete is turned on and retention is set to 30 days.  
3.2.7 - Ensure that Sotrage logging is enabled for Blob, File, Table and Queue services and is set to version 2.0  

## Non-Compliance
None.

## Standards that can't be included in deployment template.  
3.1.2 - Ensure that storage account access keys are periodically regenerated.  
3.1.4 - Ensure that shared access signature tokens expire wihtin an hour.  
3.1.5 - Ensure that shared access signature tokens are allowed only over https.  

## Further Information
[**Metro South Health - Operational and Security Standards for Azure**]( https://healthqld.sharepoint.com/teams/MSHHS-DigitalArchitectureDeliveryOffice/MSHHS-Digital-Architecture-and-Security/Shared%20Documents/Forms/AllItems.aspx?viewid=7dd8d3a0%2Df8dd%2D458a%2D9aaa%2Dece036d79981&id=%2Fteams%2FMSHHS%2DDigitalArchitectureDeliveryOffice%2FMSHHS%2DDigital%2DArchitecture%2Dand%2DSecurity%2FShared%20Documents%2FStandards)  
[**Microsoft.Storage storageAccounts template reference**](https://docs.microsoft.com/en-us/azure/templates/microsoft.storage/2019-06-01/storageaccounts)  
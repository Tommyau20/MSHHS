﻿New-MSHAZSPN -ServicePrincipalName 'mshhs-az-ite-azdevops-armtemplates-contrib-spn-01' `
            -CertCommonName "ITE Azure Devops Pipeline ARM Template SPN" `
            -AzureKeyVaultName "mshcidaskv01" `
            -Environment "Development" `
            -CertCountry "AU" `
            -CertState "QLD" `
            -CertCity "WOOLOONGABBA" `
            -CertOrganization "QUEENSLAND HEALTH" `
            -CertOrganizationalUnit "METRO SOUTH HEALTH" `
            -Verbose
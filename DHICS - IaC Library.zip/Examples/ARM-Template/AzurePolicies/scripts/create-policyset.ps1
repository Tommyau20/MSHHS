$policydefinitions = "./policyset.definitions.json"
$policysetparameters = "./policyset.parameters.json"
$policysetname = "MSH-Azure-Operational-and-Security-Standard-Testing"
$mgName = "msh-ite-das-mgmt-grp"

New-AzPolicySetDefinition `
    -Name $policysetname `
    -DisplayName $policysetname `
    -PolicyDefinition $policydefinitions `
    -Parameter $policysetparameters `
    -ManagementGroupName $mgName `
    -Metadata '{"category":"MSH","version":"1.0.0"}' `
    -Verbose
 
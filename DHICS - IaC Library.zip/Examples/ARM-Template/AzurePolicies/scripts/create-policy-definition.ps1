New-AzPolicyDefinition `
    -Name "AutoProvisioning-of-monitoring-agent-set-to-on" `
    -DisplayName "AutoProvisioning-of-monitoring-agent-set-to-on" `
    -Description "Enable automatic provisioning of the monitoring agent to collect security data." `
    -Policy './policy.rules.json' `
    -Parameter './policy.parameters.json' `
    -Mode 'All' `
    -ManagementGroupName 'msh-ite-das-mgmt-grp' `
    -Metadata '{"category":"Security Center","version":"1.0.0", "MSH-Standard":"2.1.7"}' `
    -Verbose
$subscriptionid = 'db3e6bf2-9073-4d91-b5ea-62d03c109152'

$a = Get-AzPolicyAssignment -Name 'SecurityCenterBuiltIn'
$a.Properties.PolicyDefinitionId
$a.Properties.Scope

Get-AzPolicyAssignment -Id ($a.Properties.Scope + $a.Properties.PolicyDefinitionId)

(Get-AzPolicyAssignment -id (Get-AzPolicyAssignment -Name 'SecurityCenterBuiltIn').PolicyAssignmentId).Properties.parameters.psobject.properties |
ForEach-Object {[PSCustomObject]@{
	name = $_.Name;
    defaultvalue = $_.value.defaultValue;
    allowedvalues = $_.value.allowedvalues}
}


(Get-AzPolicyAssignment -scope (Get-AzPolicyAssignment | 
    Where-Object -Property Name -eq "SecurityCenterBuiltIn").Properties.scope).properties.parameters.psobject.properties |
ForEach-Object {[PSCustomObject]@{
	name = $_.Name;
    defaultvalue = $_.value.defaultValue;
    allowedvalues = $_.value.allowedvalues}
}

(Get-AzPolicyAssignment -scope  -Id (Get-AzPolicyAssignment |
    Where-Object Name -eq "SecurityCenterBuiltIn").Properties.PolicyDefinitionId).Properties.Parameters.psobject.properties


(Get-AzPolicyAssignment -Scope (
        Get-AZPolicyAssignment -name 'SecurityCenterBuiltIn').Properties.Scope `
    -PolicyDefinitionId (
        Get-AzPolicyAssignment -name 'securitycenterbuiltin').properties.PolicyDefinitionId).Properties.Parameters.PSObject
        
    



# To check what ASC Default parameters default are
(Get-AzPolicyAssignment -Id (Get-AzPolicyAssignment | 
Where-Object  -Property Name -eq "SecurityCenterBuiltIn"
).Properties.policydefinitionid
).properties.parameters.psobject.properties |
ForEach-Object {[PSCustomObject]@{
	name = $_.Name;
    defaultvalue = $_.value.defaultValue;
    allowedvalues = $_.value.allowedvalues}
}

Get-AzPolicyAssignment



$obj = Get-AzPolicyDefinition | Select-Object -Property * -ExpandProperty Properties | 
Where-Object -Property DisplayName -eq 'Secure transfer to storage accounts should be enabled'

New-AzPolicyDefinition `
    -Name "Windows-Defender-ATP-is-enabled" `
    -DisplayName "Windows-Defender-ATP-is-enabled" `
    -Description "Ensure that Windows Defender ATP (WDATP) integration with Security Centre is turned on." `
    -Policy './policy.rules.json' `
    -Parameter './policy.parameters.json' `
    -Mode 'All' `
    -ManagementGroupName 'msh-ite-das-mgmt-grp' `
    -Metadata '{"category":"Security Center","version":"1.0.0", "MSH-Standard":"2.1.5"}' `
    -Verbose
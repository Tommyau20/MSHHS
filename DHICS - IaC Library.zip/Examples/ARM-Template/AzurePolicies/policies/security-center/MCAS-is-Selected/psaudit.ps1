# Checking for compliance with Standard 2.1.6.
# No Alias for this setting so can't be done with Azure Policy.
$obj = Get-AzSecuritySetting | where-object 'Name' -eq 'WDATP'
$obj.Enabled
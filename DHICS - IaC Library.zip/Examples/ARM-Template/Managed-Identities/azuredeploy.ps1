﻿$date = Get-Date -UFormat "%Y%m%d-%H%M%S"
$rg = 'cd01'
$rgTags = @{
    costCenterCode='2110214'
    criticality='Low'
    resOwner='Craig Dempsey'
    resOwnerDepartment='MSH Architecture & Security'
    resOwnerEmail='craig.dempsey@health.qld.gov.au'
    resOwnerPhone='0731769082'
    resOwnerPosition='Senior Technical Architect'
}
New-AzResourceGroup -Name $rg -Location 'australiaeast' -Tag $rgTags -Verbose 

New-AzResourceGroupDeployment `
    -Name ("userIdentityDeployment" + $date) `
    -ResourceGroupName $rg `
    -TemplateFile 'azuredeploy.json' `
    -TemplateParameterFile 'azuredeploy.parameters.json'



# Set-AzStorageServiceLoggingProperty `
#     -ServiceType Blob `
#     -Version 2.0 `
#     -RetentionDays 90 `
#     -LoggingOperations All `

﻿$date = Get-Date -UFormat "%Y%m%d-%H%M%S"
$rg = 'CloudShell'
New-AzResourceGroup -Name $rg -Location 'southeastasia' -Force -Verbose

New-AzResourceGroupDeployment `
    -Name ("Craigs-CloudShell-Storage-Account" + $date) `
    -ResourceGroupName $rg `
    -TemplateFile 'azuredeploy.json' `
    -TemplateParameterFile 'azuredeploy.parameters.json' `
    -Verbose



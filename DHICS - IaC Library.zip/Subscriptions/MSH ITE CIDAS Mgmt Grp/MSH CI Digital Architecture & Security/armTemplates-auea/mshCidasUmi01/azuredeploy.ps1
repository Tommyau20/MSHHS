﻿# Set the RG variables.
$date = Get-Date -UFormat "%Y%m%d-%H%M%S"
$rgName = 'armTemplates'
$rgLocation = 'australiaeast'
$rgDeploymentName = 'UserManagedIdentityDeployment'
$rgTags = @{
    costCenterCode     = '2110214'
    criticality        = 'Low'
    resOwner           = 'Craig Dempsey'
    resOwnerDepartment = 'MSH Architecture & Security'
    resOwnerEmail      = 'craig.dempsey@health.qld.gov.au'
    resOwnerPhone      = '0731769082'
    resOwnerPosition   = 'Senior Technical Architect'
    deploymentMethod   = 'Arm Template'
    system             = 'CIDAS Management'
}

#Set / Create Resource Group
$rg = New-AzResourceGroup -Name $rgName -Location $rgLocation -Tag $rgTags -Verbose -Force

# Create the Resoruce
New-AzResourceGroupDeployment `
    -Name ($rgDeploymentName + $date) `
    -ResourceGroupName $rgName `
    -TemplateFile './azuredeploy.json' `
    -TemplateParameterFile './azuredeploy.parameters.json' `
    -Verbose 








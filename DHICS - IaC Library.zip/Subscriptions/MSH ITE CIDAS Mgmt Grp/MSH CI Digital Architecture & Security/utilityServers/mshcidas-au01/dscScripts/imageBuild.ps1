# Install Dependencies
'Az.ImageBuilder', 'Az.ManagedServiceIdentity' | ForEach-Object {Install-Module -Name $_ -AllowPrerelease}

# Destination image resource group name
$imageResourceGroup = 'images'

# Azure region
$location = 'Australia East'

# Name of the image to be created
$imageTemplateName = 'customWindows2019'

# Distribution properties of the managed image upon completion
$runOutputName = 'myDistResults'

# Your Azure Subscription ID
$subscriptionID = (Get-AzContext).Subscription.Id
Write-Output $subscriptionID

# Create Resource Group
New-AzResourceGroup -Name $imageResourceGroup -Location $location

# Create useridentity adn set role permissions

[int]$timeInt = $(Get-Date -UFormat '%s')
$imageRoleDefName = "Azure Image Builder Image Def $timeInt"
$identityName = "imageIdentity$timeInt"
#create identity
New-AzUserAssignedIdentity -ResourceGroupName $imageResourceGroup -Name $identityName

# Store the idenitty resrource and principal ids in varaibles.

$identityNameResourceId = (Get-AzUserAssignedIdentity -ResourceGroupName $imageResourceGroup -Name $identityName).Id
$identityNamePrincipalId = (Get-AzUserAssignedIdentity -ResourceGroupName $imageResourceGroup -Name $identityName).PrincipalId

# Download .json config file adn modify i t based on the settings defined
$myRoleImageCreationUrl = 'https://raw.githubusercontent.com/danielsollondon/azvmimagebuilder/master/solutions/12_Creating_AIB_Security_Roles/aibRoleImageCreation.json'
$myRoleImageCreationPath = "$env:TEMP\myRoleImageCreation.json"

Invoke-WebRequest -Uri $myRoleImageCreationUrl -OutFile $myRoleImageCreationPath -UseBasicParsing


clouddrive mount -s 'db3e6bf2-9073-4d91-b5ea-62d03c109152' -g 'cloudShell' -n 'mshcidascshell01' -f 'cloudshell'
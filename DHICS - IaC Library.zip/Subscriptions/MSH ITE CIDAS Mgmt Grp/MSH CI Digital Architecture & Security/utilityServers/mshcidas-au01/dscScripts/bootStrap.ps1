#Requires -RunAsAdministrator
#Requires -version 5.1

# Check that Network connections are set to Domain or Private
Set-NetConnectionProfile -InterfaceIndex (Get-NetConnectionProfile).InterfaceIndex -NetworkCategory Private
#set-netconnectionprofile -interfaceindex (get-netconnectionprofile).intefaceindex -networkcategory Domain

# Set DNS client Address

#Set Winrm up for WindowsCompatibility module use with Powershell 6.
winrm quickconfig -quiet

#Set ExecutionPolicy
set-executionpolicy remotesigned -Force

# Add QH Certs.

$qhCert1 = @"
-----BEGIN CERTIFICATE-----
MIIEozCCA4ugAwIBAgIRAOFlKDCi67lbMuNFfvcd1mcwDQYJKoZIhvcNAQELBQAw
gYYxCzAJBgNVBAYTAkFVMRMwEQYDVQQIDApRdWVlbnNsYW5kMRswGQYDVQQKDBJl
SGVhbHRoIFF1ZWVuc2xhbmQxKDAmBgNVBAsMH0ludGVybmV0IFNlY3VyaXR5IGFu
ZCBGaWx0ZXJpbmcxGzAZBgNVBAMMEmVIZWFsdGggUXVlZW5zbGFuZDAeFw0xNjAy
MjIyMzMyMDZaFw0zNjAyMTcyMzMyMDZaMIGGMQswCQYDVQQGEwJBVTETMBEGA1UE
CAwKUXVlZW5zbGFuZDEbMBkGA1UECgwSZUhlYWx0aCBRdWVlbnNsYW5kMSgwJgYD
VQQLDB9JbnRlcm5ldCBTZWN1cml0eSBhbmQgRmlsdGVyaW5nMRswGQYDVQQDDBJl
SGVhbHRoIFF1ZWVuc2xhbmQwggEiMA0GCSqGSIb3DQEBAQUAA4IBDwAwggEKAoIB
AQCfd7HlwYtfQNYUxL4nnk1ogOU+X9wbpi94irCw3Y9Sag6euoGmU7SthvQ5KQsh
fwGawiXa67X27yMDxGT8wuqCRS/CXmf+9vLudZr2u3MIhRmJm1EuJJjlB+rdqa2Z
UxuE+bCSXlAQKxD09VziedB4AT6mdUdMzHaMgOw29DmAWkVMD0A67c2KiO5vDpE0
Zq6V0spNcmDW2xsDrjXd5+FUZKsfHyqlV6Rh9Zxo63I0IT1LBvAV8B2GpydouXhR
hfirG7wYSU8BfSwd8Pn8gWzKZzzSyTqbR12QrF/CwLT4qwO6LR9Ge59WJVC105CR
XubI5CG5X+bsBFqm6F/i+nPxAgMBAAGjggEIMIIBBDAMBgNVHRMEBTADAQH/MB0G
A1UdDgQWBBRwwABv+G8deXAWgNCKArwUWo1PGDCBwwYDVR0jBIG7MIG4gBRwwABv
+G8deXAWgNCKArwUWo1PGKGBjKSBiTCBhjELMAkGA1UEBhMCQVUxEzARBgNVBAgM
ClF1ZWVuc2xhbmQxGzAZBgNVBAoMEmVIZWFsdGggUXVlZW5zbGFuZDEoMCYGA1UE
CwwfSW50ZXJuZXQgU2VjdXJpdHkgYW5kIEZpbHRlcmluZzEbMBkGA1UEAwwSZUhl
YWx0aCBRdWVlbnNsYW5kghEA4WUoMKLruVsy40V+9x3WZzAPBglghkgBhvhCAQ0E
AhYAMA0GCSqGSIb3DQEBCwUAA4IBAQAsuGC7vyqL2T8kQtzgglT28GaCegAdLFkp
P5tfOpd6SKONNpCA3O0IPz28B7eybaJ5TrHGx9HYh2R8aEmDH2k8iGhj1VvFGlq5
JtqYK7U6AdIPscdebDNRmiAXnVR2aMk24+S4r8YFN/l0GzezUrM/UxqjBwhp7yHK
xiNzGPo0CiuWoqNh7b+3MkehwudFfihclxYA8Fqma3R+lwgER77fwXuxQs3HT6O5
p/R2MA7S2XZbo9Zl+DqcFHiRNKCNAyVQKg+fdbvqaDoMlqeZDwEFcslOHB6oVsHH
D4EW5up7gy5homz0X0NOd/YaOFJbnI5xpejKIA9mEZyukItjNBgv
-----END CERTIFICATE-----
"@


if (!(Test-Path -Path 'C:\admin\qhCerts\eHealth_Queensland.cer')) {
    New-Item -Path 'C:\admin\qhCerts\eHealth_Queensland.cer' -ItemType File -Value $qhCert1 -Force 
}

$file = ( Get-ChildItem -Path "C:\admin\qhCerts\eHealth_Queensland.cer" )
$file | Import-Certificate -CertStoreLocation Cert:\LocalMachine\Root\ -verbose

$qhCert2 = @"
-----BEGIN CERTIFICATE-----
MIIFhzCCA2+gAwIBAgIQUWkt6W13O37x5T7NH0ga8DANBgkqhkiG9w0BAQsFADBc
MQswCQYDVQQGEwJBVTEbMBkGA1UEChMSREVQVCBPRiBIRUFMVEggUUxEMRswGQYD
VQQLExJlSGVhbHRoIFF1ZWVuc2xhbmQxEzARBgNVBAMTClFIUEtJIFJPT1QwHhcN
MTYwNjE0MDAwMDAwWhcNMzYwNjEzMjM1OTU5WjBcMQswCQYDVQQGEwJBVTEbMBkG
A1UEChMSREVQVCBPRiBIRUFMVEggUUxEMRswGQYDVQQLExJlSGVhbHRoIFF1ZWVu
c2xhbmQxEzARBgNVBAMTClFIUEtJIFJPT1QwggIiMA0GCSqGSIb3DQEBAQUAA4IC
DwAwggIKAoICAQDHuUvZYih5SUow7BZDzJM78/aH9eEsNNtNKRgwF2Q3kL4887BX
/XWhORGzGM5YyuApPmNioJ6YdEGBbm/jpQ0HWAdDV5OEyNzqDzCXkX7iVPnRfi10
uDKG8/bW+w5NNtcykGXv86RfF2fPEt4U3OFF+BjHz0GhSNyPab2q/dOuxvJtC/0G
0XogNuhEDNhkUCVgHKKQ6ivobL1Q/a282oIQ6EIeS5EshNXmoR+zS8N9MnC0KjTP
Ir5Uqd+Ff7ReC4KJysafgEpbZjiYZdQniSDMUQud0R8yG3fgLfLIfCk2Tx0NWjla
Nwz7Ic8UGy0xuN8BNYWn9wDlr5P4x6cHAmsGRMoggBYF+kvjiryLqdHjNNQ7chv8
WJR1/dqlrVeinulIFANLuNHUi7jkYCgdyJ8+H5NkAd7AfzG+xXpb2oyUcN6ElI1m
PGl07/kqZfbN2C/GogGqNXqJd1Mh6o42P1F3VtK2PGU+GMMWluj+gQ1al+FwHX5D
8mxv3tsiP+tk7pO7uj4H0KxEcI+SDk2AkFeQFg5BsuMpMqQ+0SELXcRbhewtIe1L
BkvZ6nTE/pRU6sWoKF4JHWo8wP5K3dDsa9EQkL8KSc+Tnap3I6qU9V70JYaAmf7S
wIOxA6MrehF57GpA7hfyDvMB0UM0JsW1e4IOr72A0JUfSgoBj3N30LxoowIDAQAB
o0UwQzASBgNVHRMBAf8ECDAGAQH/AgEBMA4GA1UdDwEB/wQEAwIBBjAdBgNVHQ4E
FgQUx4bzfkl0zYisuXto5J30H/LiME4wDQYJKoZIhvcNAQELBQADggIBALTkljQ4
XZg31zqYLijejAey3rOr18/4Caw+aWyPgsRIdqADWkVSueUaq1k19dTygDoSrXXQ
fz4iz9zfN8hqO88BzrGoKlD9FBFErxTl8owDGM8EdTlMV22MGqsMJ2vMtV+A0/9k
884I14Imtrt1aZo7h2xw81A+jxELbufDCQEDIQH/uR6LxOCOomdIyC9/XWotpeh0
zE+dNwCkLKmbpffJzKm9nF/f5B9DbtGgUtRHXi+KcGe0Xn7zdltIoZ2KKE2UFrqK
CWUY12VyNxkV6wj7PqCMsv+/Hi40oy+4lUiTVzp8HDKy+9FyOlNLoeQnN18/qTol
jgvNE99mI0RrbP2WbixZ7YSdMubnQtgb8VkFBKyN5fHxHIQDtOx/+5XBGDCNCJ+s
V6Lml9HqK+j1O+kHwJthdmm4/MdYkhF11FAlTAWhHXlcIoh5ybVY9XeEz3HRjbAE
ZyBTsiMcZ/bgJ2K41BYQiRGeU4Wml/yMRRA9oODIe0gio6f7tqvfthib9Pt5cLTH
NQAYR07muRHdNEKcQ8v5ef4W+xfCPJxJPnUtd3TNkoKCreoPPxf9q9pSC1LqYEWu
Z6WDLN1eop/6FwH4rjqll+mx+2tzy9Zgq29dE5K1pJuDGv1WzxHfm7z0J6Inl3Tv
94lsC3qkJCFsfgubvW/miQPvqdmKHX0d7pyt
-----END CERTIFICATE-----
"@

if (!(Test-Path -Path 'C:\admin\qhCerts\qhpkirootca.cer')) {
    New-Item -Path 'C:\admin\qhCerts\qhpkirootca.cer' -ItemType File -Value $qhCert2 -Force 
}

$file = ( Get-ChildItem -Path "C:\admin\qhCerts\qhpkirootca.cer" )
$file | Import-Certificate -CertStoreLocation Cert:\LocalMachine\Root\ -verbose

$qhCert3 = @"
-----BEGIN CERTIFICATE-----
MIIGIzCCBAugAwIBAgIQCbY4HGv5bpOD2H6Y6J9JwjANBgkqhkiG9w0BAQsFADBc
MQswCQYDVQQGEwJBVTEbMBkGA1UEChMSREVQVCBPRiBIRUFMVEggUUxEMRswGQYD
VQQLExJlSGVhbHRoIFF1ZWVuc2xhbmQxEzARBgNVBAMTClFIUEtJIFJPT1QwHhcN
MTYwNjE0MDAwMDAwWhcNMzEwNjEzMjM1OTU5WjBpMQswCQYDVQQGEwJBVTEbMBkG
A1UEChMSREVQVCBPRiBIRUFMVEggUUxEMRswGQYDVQQLExJlSGVhbHRoIFF1ZWVu
c2xhbmQxIDAeBgNVBAMTF0RFVklDRSBCQVNJQyBJU1NVSU5HIENBMIICIjANBgkq
hkiG9w0BAQEFAAOCAg8AMIICCgKCAgEA0BGmVfpUUYnGfN5DYlp2LFq3X2BXHdYT
ZCP3UNX9orT8RzS3+JI/qArDoukzc4kerZOFsZfH8Kg60Kw2tzoNhwIRzyhjIDkY
cQhr8/6EPAgG25TUlQnv1/vKif5soueSFIFIV+V1lFjmn+8tLi3cG5EIW4Eyuias
+bUhWXBnqn/ucPkiyIHXCu2Oh4mDcdkldEcfSddPZ+dqnGKyJ6FMxazDyh1qyV+Q
a+C0oQdYU5SSPNuwDZuRuV22qUtEWjxwrNydiRXqizo8w5Z3tbBmx9DHqhilbxhO
KknqSP7VmYrkoNRJQF/6R2OPUtlTldA0t4sjYlitj2WHXnq8OWrD69fACO4hLZm6
2B+xmxzJLUBHeol2NyMqMopX7ih1huXjbymPmr+Qv66ADbfl4ED7KrS4Jf+toL0k
SzD17oDt2YqquNbhbtNJ3P4mFWVQIIqYqpCgeOSFbJDTBgVZyl3YjMdjFBvc1zaA
quOvRdfxP4JvWs05V1LkIHzmo497wFRgXtlaW8NPzCfESza37bC8HcmZLUin52Qh
hY7RUagkpNthb/CTX0t5xz/stvcP4Ji7jbMVLBc2MY6rD0IZNmc1uQDeDTPoWGkG
wnE1k4WVDhdSgF6Jc3XsmS7AtqoDVcMs2O/2zZhTb22E1tdIwx3PgmS3+nPvHcRw
jTADo+icrw8CAwEAAaOB0zCB0DAdBgNVHQ4EFgQUbCR9F683C3l/nVcjbcX3sEgQ
YmAwEgYDVR0TAQH/BAgwBgEB/wIBADBEBgNVHR8EPTA7MDmgN6A1hjNodHRwOi8v
cGtpLmhlYWx0aC5xbGQuZ292LmF1L1FIUm9vdC9RSFBLSVJvb3RDQS5jcmwwDgYD
VR0PAQH/BAQDAgEGMCQGA1UdEQQdMBukGTAXMRUwEwYDVQQDEwxTWU1DLTQwOTYt
MjgwHwYDVR0jBBgwFoAUx4bzfkl0zYisuXto5J30H/LiME4wDQYJKoZIhvcNAQEL
BQADggIBAHBvKB/9YnnBuIMCko42rmLUBZD3DkYxnf5rBJQpQRfM6tWstTrhzorU
4MxCg4dhYgeKWr14ZPphPYCybL+hDHyLKF+EuRG3hBuwRofvgexsuqf+vleKf+88
rVvfP0nFdRZHizZCNck8iqX+nu5+8rdZzJgOmb/nLRYklkN/mUQNL6FEc23zCvEB
2D9+LsZ2Z7m58mg1AsZx0ACol/SKHaIPi8IMRyhVBGD0j8G7Knx1kkFU04bhddrn
Aglzyi4m86vf5pKnjGuiqvUtCWEMDU+n/nhXW4IP6b+FzdpQnPFRp1dww2SkVF6I
JOVCXh1UdLs7bWZ/Rh/IRjVmljmXigIn7U0FAl+mLUe9Ngq0dNs1RG3VGMpf6zTS
a57JnCY/okl5WJL9VJdTPe5Q/NER0k407OojGZ/UM40RXI9SzwDpz+oa2wWPvl+z
sDGNISx6cLbkoqye1wZAq6yn2cRXJ+/Ct2+3idd9Wz91McVBxn269NA35XrL6LK6
uVlKKhMSEXLlghqcOMmuZO2WotPc7FP5ufgHUbpAj4fe7lj8NCo3yHSRKJrEczMM
o01wB8h5TY9GfwkbXxT+hVMM7zbxgaInWMqmmThu9KpjSe/WEyEZWQOoCW0pCmDA
HGETEBswMu04vwKd0y1lSRLT/8806F8SeP65GLo2GWjuTgEJrFE0
-----END CERTIFICATE-----
"@

if (!(Test-Path -Path 'C:\admin\qhCerts\DEVICE-BASIC-ISSUING-CA.cer')) {
    New-Item -Path 'C:\admin\qhCerts\DEVICE-BASIC-ISSUING-CA.cer' -ItemType File -Value $qhCert3 -Force 
}

$file = ( Get-ChildItem -Path "C:\admin\qhCerts\DEVICE-BASIC-ISSUING-CA.cer" )
$file | Import-Certificate -CertStoreLocation Cert:\LocalMachine\Root\ -verbose


$qhCert4 = @"
-----BEGIN CERTIFICATE-----
MIIGJTCCBA2gAwIBAgIQSiqmtE7yp72JDCNkiTFWmzANBgkqhkiG9w0BAQsFADBc
MQswCQYDVQQGEwJBVTEbMBkGA1UEChMSREVQVCBPRiBIRUFMVEggUUxEMRswGQYD
VQQLExJlSGVhbHRoIFF1ZWVuc2xhbmQxEzARBgNVBAMTClFIUEtJIFJPT1QwHhcN
MTYwNjE0MDAwMDAwWhcNMzEwNjEzMjM1OTU5WjBrMQswCQYDVQQGEwJBVTEbMBkG
A1UEChMSREVQVCBPRiBIRUFMVEggUUxEMRswGQYDVQQLExJlSGVhbHRoIFF1ZWVu
c2xhbmQxIjAgBgNVBAMTGU1PQklMSVRZIEJBU0lDIElTU1VJTkcgQ0EwggIiMA0G
CSqGSIb3DQEBAQUAA4ICDwAwggIKAoICAQC4rwgU7igABcFoNXWbH+n3FEyz9Bic
VTm0dUH0zeZ1kbJz6ZyErz08sdGIV4LK06MXXgTXOMqWuMXuhDxwWryGZHJt/GYt
Bpls//ZRAXr5FvmlEQ+FGogiv82KJ/QK8yMfuGZyJ+rGU1lLwZB3lc4YybOEpawW
6L0J3Bvsgo3zoCLFblzI1T37DIjhJ9tWYNDkzxmZqrden/qktDTWs40PUBcwdja9
fozpnZ7PnyrFT/Nm9R+kBj5vB/lm1oqmNpnxEMg8fF6tJKwI8H4+NcdjtvW/xUzh
vr573W1Haqshx56Rfp3ADJjLb262veOG27IosV/be012OvH84m0XBos1LXqs8A7h
SF51p1P16884YBkTs2mmMyFMM/k9gd2bLBjZwN6aU1EeKFoJuBCVsyEhthG3+FQV
6cvqJONpn67Ps/neVhLIfcmsIMECATutVbtiErFQ8BPYMsC9u7zQRm6jITRLzGTL
592OfLz6HfVHBkSnz0HoPvYCRnA9tN3Tjm6GgcdW7MxfbUHUiQTGQPHSwMmQodgR
b/SzLBEAl7Xn9h+bHWc9QSuITg24Id5YxTTY81kw4yfzroPiYYVc0waYRSwNoPCn
EtoDi3mELlAFrRtlVCHnlRlqDxw+cyEV0br7c+I6QiSsCsU1DBklxF/qWh6hPOQj
NVAxlSp1HPNAHwIDAQABo4HTMIHQMB0GA1UdDgQWBBQkJdwvGMxHHnLcIa41wkKg
TkBXUDASBgNVHRMBAf8ECDAGAQH/AgEAMEQGA1UdHwQ9MDswOaA3oDWGM2h0dHA6
Ly9wa2kuaGVhbHRoLnFsZC5nb3YuYXUvUUhSb290L1FIUEtJUm9vdENBLmNybDAO
BgNVHQ8BAf8EBAMCAQYwJAYDVR0RBB0wG6QZMBcxFTATBgNVBAMTDFNZTUMtNDA5
Ni0yOTAfBgNVHSMEGDAWgBTHhvN+SXTNiKy5e2jknfQf8uIwTjANBgkqhkiG9w0B
AQsFAAOCAgEASJMVWCXi83db+dwFgErFTx2kiVDXxjJxIRDj6uAb3stj2O7DerZ7
nrUCh+XK5YT7TsU0c1+XGoZ/NtlXJm2qX0idPgnNcCkwU8z5Fw4GgmwHYl+LsJVr
QuqHuIJJerP6wcW0BusYi0RBLNbOZ9fV4uEN50GWyKbuq9g5i/NBAmmnbZhkYmK4
UyEteLXiqCvo5nY8ELnhs/uHI6Z12eWjPlvCYyHd36tNZVqRaTDhPbRC3IvepCfO
zxCsecPzZAKN0iAPVgwuH8RoHa11UqFqeiJCEanh9WlAavl5ExnoZj70ADB0DjfL
d6WtfmrXNAkb8JKK+TtKvLtd8+WFEkkWNrV1nE5Mk6m6uhv9LohnulzD54GGTWdy
l79H3NEjBZSIJ+ti5I64nFNh6k0Frdd4qZhBAeov5jm2la7EOjaw+8t4veKm9rJa
vVa/2egDe93xq+u7DFoPqr9EAgwe8twgfIiDi0G2GD8BgqTCGa5ILx5jFeUABKAg
Km22t60QXxOz8i/WcqNK0vGPf78PKB5Lia8Xs016xIQWnSsQzRkwyBmoJbQffPKR
fkMcH20bhTZdlQt3kD3W1sFA9VSk928ZqXOCl2Ceum/fb57PHiv1yqppt3SJrJxF
gpvaa+ykJPaub0IFXUiX9umxmJJFKLJpZ4zZgGZlyDggzJO28jZLPT8=
-----END CERTIFICATE-----
"@

if (!(Test-Path -Path 'C:\admin\qhCerts\MOBILITY-BASIC-ISSUING-CA.cer')) {
    New-Item -Path 'C:\admin\qhCerts\MOBILITY-BASIC-ISSUING-CA.cer' -ItemType File -Value $qhCert4 -Force 
}

$file = ( Get-ChildItem -Path "C:\admin\qhCerts\MOBILITY-BASIC-ISSUING-CA.cer" )
$file | Import-Certificate -CertStoreLocation Cert:\LocalMachine\Root\ -verbose

$qhCert5 = @"
-----BEGIN CERTIFICATE-----
MIIGITCCBAmgAwIBAgIQDlIqGVHsHjyXQHh5q+R2gDANBgkqhkiG9w0BAQsFADBc
MQswCQYDVQQGEwJBVTEbMBkGA1UEChMSREVQVCBPRiBIRUFMVEggUUxEMRswGQYD
VQQLExJlSGVhbHRoIFF1ZWVuc2xhbmQxEzARBgNVBAMTClFIUEtJIFJPT1QwHhcN
MTYwODI2MDAwMDAwWhcNMzEwNjA4MjM1OTU5WjBnMQswCQYDVQQGEwJBVTEbMBkG
A1UEChMSREVQVCBPRiBIRUFMVEggUUxEMRswGQYDVQQLExJlSGVhbHRoIFF1ZWVu
c2xhbmQxHjAcBgNVBAMTFVVTRVIgQkFTSUMgSVNTVUlORyBDQTCCAiIwDQYJKoZI
hvcNAQEBBQADggIPADCCAgoCggIBALwCq/9lTUxEA036s5UlJLwzRPxBL1sJfEnb
794/KRU/9Gm4pt6mc8k/bSL8eBuh1xpV9iZsEeqjcefj2BFAYtkMT+cK6UawXfhx
foZGkEHKQyBuKTdz8MxdaPvSvcC3nFZ7N1jPzZww0zxd2OmpdFdEpK60er57Fzu6
duzR8kHH82kwVqiAY6cPqJBp2uKbDqNEbbqXJRFu8NHNcIfLv9t0swlAcGwbGoWc
icXCObVJ4qK44HAGyFZ3Gv20Iqf7mFStirvc8qzpODnteqmZM66YMUEBHxKU53y7
c9ie+qlO9CJ1ha0Q2KyO41eIZ8F9We5Kcpk2Q87BzkfAWOk2bbCNe8oijwRzZDWu
Xn4ICvYU2cZDV35pas8Hiw9Qa/KkMX77m+qInMMLwp0zZb0Jh9ogzaXtCLrp5s40
quxMEvilezePkKhObH0YrM6VzbJ3EUU33uV2TSPeZKys27FHFnkXEkU7ob1cEI98
28hSX0pMHr0quE1905rjArv5NnYSOoI+3WUE2OV2OhLDCprg1JDT8Ho52L5j/ya/
qN8VHgLAyLN5ekgCVmTxYfKEtAuZzAEXEr6YKeidIP0JlxCfYKTCVs0Uh4MAWwDZ
ZZIpkOkF1jvHQtvem4caJdpzA73WLvc20B37fwlBQ/adgvAA+V+y7Se2krzi8y15
6hk2C00bAgMBAAGjgdMwgdAwEgYDVR0TAQH/BAgwBgEB/wIBADBEBgNVHR8EPTA7
MDmgN6A1hjNodHRwOi8vcGtpLmhlYWx0aC5xbGQuZ292LmF1L1FIUm9vdC9RSFBL
SVJvb3RDQS5jcmwwDgYDVR0PAQH/BAQDAgEGMCQGA1UdEQQdMBukGTAXMRUwEwYD
VQQDEwxTWU1DLTQwOTYtMzEwHQYDVR0OBBYEFBWceh0PVYN5wmSD4Hkabh0kWxEJ
MB8GA1UdIwQYMBaAFMeG835JdM2IrLl7aOSd9B/y4jBOMA0GCSqGSIb3DQEBCwUA
A4ICAQA0E2JF1GRheM3+zv7KX21paauChdzZ8ahjDo+pb1xQQ94TwcdKfz4IcxZk
N+bNy/EDS+o6NpKQtmBQofNsDikqitdwuQobNv9hTvVtzEJ6UPr2cR+WInv/Q0KD
+FY7iJueTZ7jUXYd/pEemJbUKjyg+zzCOlaCGOiRgjtaw8dMOU82ReD2ZfRQC4zF
f2LR10qccuaAA3Xd0AVlW8BnyjSsglOlAbUtNQ50ipxKrAVRXYfZxuhCGWoc7GhL
y6CkGhba7KgoioHoa+YKFqygAgD4RXK1VLf3moxKndnpb2va7z0EWTLnWrLSY37L
Nql8xKEVpkTvu1Za6fvB8RW4wBTFltcyXZxNFUBGAKEJKtX4c3e85bHysnPHkrG4
G7W+C0uNBBjq1MnaM20ra0iq3knNcocnAIZ9rA6Q20ID7u/fZTEBvrBzJBUrMw2f
ODbtc4zpm68PISqOM+OKAJIYiy0SRbjgHAiN3Ilt69mc1Gjw6rz01w0+5ZzBn1UC
oYubO9HzzjOWywolCMEoiFTSYccTAq3fLOHyLLtYvOahdiNAYLMvkEIeR6ivBHV6
aHy6aNMQhfi3VRAePLv/RCSlglJO0NYk/w45TMb0pcb6bfImZ4f/ShvH97Qk9n88
C4pjxce7eCHMCQrhdITkm/1hnyle+NP5qeZBVtuMJ1ysbzOrqg==
-----END CERTIFICATE-----
"@

if (!(Test-Path -Path 'C:\admin\qhCerts\USER-BASIC-ISSUING-CA.cer')) {
    New-Item -Path 'C:\admin\qhCerts\USER-BASIC-ISSUING-CA.cer' -ItemType File -Value $qhCert5 -Force 
}

$file = ( Get-ChildItem -Path "C:\admin\qhCerts\USER-BASIC-ISSUING-CA.cer" )
$file | Import-Certificate -CertStoreLocation Cert:\LocalMachine\Root\ -verbose

# Add Proxy Environment Variables.

    # Set winhttp proxy
    Write-Host "Setting the Winhttp Proxy....."
    netsh winhttp set proxy proxy-icf.health.qld.gov.au:8088 "<local>;10.*.*.*;*.health.qld.gov.au" | Out-Null

    # Set environment variable.
    Write-Host "Setting User Environment Variables....."
	# Sets HTTP Proxy to Unauthenticated Proxy.
	[System.Environment]::SetEnvironmentVariable('HTTP_PROXY', 'http://proxy-icf.health.qld.gov.au:8088', [System.EnvironmentVariableTarget]::machine)
	# Sets HTTPS Proxy to Unauthenticated Proxy.
	[System.Environment]::SetEnvironmentVariable('HTTPS_PROXY', 'http://proxy-icf.health.qld.gov.au:8088', [System.EnvironmentVariableTarget]::machine)
	# Sets Proxy Bypass
	[System.Environment]::SetEnvironmentVariable('NO_PROXY', 'localhost,.health.qld.gov.au,10.', [System.EnvironmentVariableTarget]::machine)
	# Sets Python to use eHealth SSL CA Cert. https://docs.python.org/3/using/cmdline.html#environment-variables
	[System.Environment]::SetEnvironmentVariable('REQUESTS_CA_BUNDLE', 'C:\admin\qhcerts\eHealth_Queensland.cer', [System.EnvironmentVariableTarget]::machine)
	# Sets Node to use eHealth SSL CA Cert. https://nodejs.org/api/cli.html#cli_environment_variables
	[System.Environment]::SetEnvironmentVariable('NODE_EXTRA_CA_CERTS', 'C:\admin\qhcerts\eHealth_Queensland.cer', [System.EnvironmentVariableTarget]::machine) 
	# Tells Git to use eHealth SSL CA Cert. https://git-scm.com/docs/git-config
	[System.Environment]::SetEnvironmentVariable('GIT_SSL_CAINFO', 'C:\admin\qhcerts\ehealth_queensland.cer', [System.EnvironmentVariableTarget]::machine) 

# Force a refresh of the environment variables 

#Refresh environment variables
foreach($level in "Machine","User") {
    [Environment]::GetEnvironmentVariables($level).GetEnumerator() | % {
       # For Path variables, append the new values, if they're not already in there
       if($_.Name -match 'Path$') { 
          $_.Value = ($((Get-Content "Env:$($_.Name)") + ";$($_.Value)") -split ';' | Select -unique) -join ';'
       }
       $_
    } | Set-Content -Path { "Env:$($_.Name)" }
 }
 
 # Install Chocolatey
Set-ExecutionPolicy Bypass -Scope Process -Force; iex ((New-Object System.Net.WebClient).DownloadString('https://chocolatey.org/install.ps1'))

#Refresh environment variables
foreach($level in "Machine","User") {
    [Environment]::GetEnvironmentVariables($level).GetEnumerator() | % {
       # For Path variables, append the new values, if they're not already in there
       if($_.Name -match 'Path$') { 
          $_.Value = ($((Get-Content "Env:$($_.Name)") + ";$($_.Value)") -split ';' | Select -unique) -join ';'
       }
       $_
    } | Set-Content -Path { "Env:$($_.Name)" }
 }

# # Install Base Software
# choco install git `
#               powershell-core -y
# logsStorage

This Resource Group will house all central storage accounts to manage logs. The logs are set to immutable for 90 days.
<#
#################################################################################################################

READ FIRST

This script is designed to be run manually, step by step. Open the script using VS Code,
highlight each section and then right click and select Run Selection.

Due to enabling Key Vault Soft Delete and disabling the ability to purge from the key vault manually,
a secret or certificate can't be over-written. You can't use the same name twice. If you want to run this
script multiple times, you'll need to specify a different Service Principal Name each time you run it. The
easiest way to do this is to just interate by number.

You will need to manually clean up after yourself. If you are running this script to test be aware that you will
need to : -
- Delete the secret and the certificate from the keyvault.
- Remove the Role Assignment from the Resource Group or Subscription.
- Delete the Service Principal / App Registration from Azure AD.

Be aware that this version of the script gives contributor permissions to the Service Principal for the Resource
Group. If you need it for Subscription then you can change the Role Assignment cmdlet in Step 20.

#################################################################################################################
#>

#Region Step 1 - Login to Azure and Set the correct Subscription Context.
Login-AzAccount -Subscription $SubscriptionName

# Confirm that you are in the correct context.
Get-AzContext
#EndRegion

#Region Step 2 - Set the variables
$SubscriptionName='MSH CI UAT Subscription'
$ServicePrincipalName='mshhs-az-uat-azdevops-armtemplates-contrib-spn-01'
$ResourceGroupName='dhito-msh-uat'
$CertCommonname='UAT Azure Devops SPN' ## Can't be longer than 64 Chars or it will break the openssl command.
$AzureKeyVaultName="auea-core-kv01-test"
$Environment="UAT"
$CertCountry="AU"
$CertState="QLD"
$CertCity="WOOLOONGABBA"
$CertOrganization="QUEENSLAND HEALTH"
$CertOrganizationalUnit="METRO SOUTH HEALTH"
#EndRegion

#Region Step 3 - Set the verbose preference for your Powershell Session.
$VerbosePreference = 'Continue'
#Endregion

#Region Step 4 - Check if Secrets Exist in KeyVault

# Check if Service Principal Password or Passphrase is in the Key Vault or has been soft deleted but not purged.
if ($null -eq (get-azkeyvaultsecret -vaultname $AzureKeyVaultName -name ('Passphrase-' + $ServicePrincipalName) -InRemovedState)){
    Write-Verbose "There is no secret with the name `'Passphrase-$ServicePrincipalName`' in soft delete that hasn't been purged."
}
else{
    Write-Error "The Secret has already has been deleted from the Key Vault but it hasn't been purged, Soft delete is on so you'll have to choose another Service Principal Name."
    Break
}
if ($null -eq (get-azkeyvaultsecret -vaultname $AzureKeyVaultName -name ('Password-' + $ServicePrincipalName) -InRemovedState)){
    Write-Verbose "There is no secret with the name `'Password-$ServicePrincipalName`' in soft delete that hasn't been purged."
}
else{
    Write-Error "The Secret has already has been deleted from the Key Vault but it hasn't been purged, Soft delete is on so you'll have to choose another Service Principal Name."
    Break
}
if ($null -eq (get-azkeyvaultsecret -vaultname $AzureKeyVaultName -name ('Passphrase-' + $ServicePrincipalName))){
    Write-Verbose "There is no secret with the name `'Passphrase-$ServicePrincipalName`' in the key Vault"
}
else{
    Write-Error "The Secret is already in the Key Vault you'll need to choose another name for the service principal."
    Break
}
#EndRegion

#Region Step 5 - Generate Random Password and import to KeyVault
function Get-RandomCharacters($length, $characters) {
    $random = 1..$length | ForEach-Object { Get-Random -Maximum $characters.length }
    $private:ofs = ""
    return [String]$characters[$random]
}

$CertificatePassphrase = Get-RandomCharacters -length 48 -characters 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-='
Set-AzKeyVaultSecret -VaultName $AzureKeyVaultName -Name ('Passphrase-'+ $ServicePrincipalName) -SecretValue (ConvertTo-SecureString -String $CertificatePassphrase -AsPlainText -force)
$CertificatePassword = Get-RandomCharacters -length 48 -characters 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+-='
Set-AzKeyVaultSecret -VaultName $AzureKeyVaultName -Name ('Password-' + $ServicePrincipalName) -SecretValue (ConvertTo-SecureString -String $CertificatePassword -AsPlainText -force)
#EndRegion

#Region Step 6 - Check that $env:userprofile/.secret has been created.
if(!(Test-Path $env:USERPROFILE\.secret)){
    New-Item -ItemType Directory -Name '.secret'
}
else{
    Write-Verbose 'The .secret folder is already created.'
}
#EndRegion

#Region Step 7 - Check that $env:USERPROFILE/.secret is read only.

# Make sure that .secret is only readable and writeable by the logged in user.
$ACL = Get-acl $env:USERPROFILE\.secret
if ($acl.owner -eq $acl.Access.IdentityReference.Value -and $acl.access.Count -eq 1){
    Write-Verbose "$env:userprofile\.secret is already set to read-only. No need to change permissions."
}
else{
    $acl.SetAccessRuleProtection($true,$false)
    $UserAccount = New-Object -TypeName System.Security.Principal.NTAccount -ArgumentList ($env:userdomain + "\" + $env:username);
    $acl.SetOwner($UserAccount)
    $AccessRule = [System.Security.AccessControl.FileSystemAccessRule]::new(
                    $env:USERNAME,
                    "FullControl",
                    ([System.Security.AccessControl.InheritanceFlags]::ContainerInherit -bor [System.Security.AccessControl.InheritanceFlags]::ObjectInherit),
                    [System.Security.AccessControl.PropagationFlags]::None,
                    [System.Security.AccessControl.AccessControlType]::Allow)
    #$Acl.AddAccessRule($AccessRule)
    $Acl.SetAccessRule($accessrule)
    Write-Verbose "$env:userprofile\.secret is NOW set to Readonly. Permissions have been changed."
}
#EndRegion

#Region Step 8 - Check pre-requisites are installed.

#Checking OpenSSL is installed.
Write-Verbose "Checking if OpenSSL is installed."
if($null -eq (openssl version)){
    Write-Warning "You need to install OpenSSL. Exiting..."
    Break
}
else{
    Write-Verbose ((openssl version) + " is installed.")
}
Write-Verbose "Checking if Powershell AZ Module is installed."
if($Null -eq (get-module 'az' -ListAvailable -Verbose:$false)[0]){
    Write-Warning "You need to install the Azure Powershell Module called 'Az'. Exiting..."
    Break
}
else{
    Write-Verbose "AZ Module is installed."
}
#EndRegion

#Region Step 9 - Generate the CSR

Write-Host "Generating CSR..."
## Generate the CSR
# openssl req -newkey rsa:4096 `
#             -nodes `
#             -passout pass:(Get-AzKeyVaultSecret -VaultName $AzureKeyVaultName -Name ('Passphrase-' + $ServicePrincipalName)).SecretValuetext `
#             -keyout "$env:userprofile\.secret\$ServicePrincipalName.key" `
#             -out "$env:userprofile\.secret\$ServicePrincipalName.csr" `
#             -subj "/C=$CertCountry/ST=$CertState/L=$CertCity/O=$CertOrganization/OU=$CertOrganizationalUnit/CN=$CertCommonName" #>$null 2>&1
openssl req -newkey rsa:4096 `
            -nodes `
            -passout pass:$CertificatePassphrase `
            -keyout "$env:USERPROFILE\.secret\$ServicePrincipalName.key" `
            -out "$env:USERPROFILE\.secret\$ServicePrincipalName.csr" `
            -subj "/C=$CertCountry/ST=$CertState/L=$CertCity/O=$CertOrganization/OU=$CertOrganizationalUnit/CN=$CertCommonName" #>$null 2>&1
#Endregion

#Region Step 10 - Signing the CSR

Write-Host "Signing the CSR..."
# Sign the CSR
openssl x509 -signkey "$env:USERPROFILE\.secret\$ServicePrincipalName.key" `
            -in "$env:USERPROFILE\.secret\$ServicePrincipalName.csr" `
            -req `
            -days 365 `
            -out "$env:USERPROFILE\.secret\$ServicePrincipalName.crt" #>$null 2>&1
#EndRegion

#Region Step 11 - Export the PFX Certificate

Write-Host "Exporting the PFX Certificate..."
# Export the PFX certificate
openssl pkcs12 -export `
            -password pass:$CertificatePassword `
            -out "$env:USERPROFILE\.secret\$ServicePrincipalName.pfx" `
            -inkey "$env:USERPROFILE\.secret\$ServicePrincipalName.key" `
            -in "$env:USERPROFILE\.secret\$ServicePrincipalName.crt" #>$null 2>&1
#EndRegion

#Region Step 12 - Generate PEM from PFX
#Generate PEM from PFX
openssl pkcs12 `
            -in "$env:USERPROFILE\.secret\$ServicePrincipalName.pfx" `
            -out "$env:USERPROFILE\.secret\$ServicePrincipalName.pem" `
            -passin pass:$CertificatePassword `
            -passout pass:$CertificatePassphrase `
            -nodes #>$null 2>&1
#EndRegion

#Region Step 13 - Grab the Certificate Thumbprint

Write-Host "Grabbing the fingerprint"
# Grab the fingerprint from the PFX.
$fingerprint = openssl pkcs12 -in "$env:USERPROFILE\.secret\$ServicePrincipalName.pfx" -nodes -passin pass:$CertificatePassword | openssl x509 -noout -fingerprint
$fingerprint = $fingerprint.split("=").replace(":","")[1]
#EndRegion

#Region Step 14 - Import Certificate into Azure Key Vault
# Step - Import Certificate into Azure Key Vault
Write-Host "Importing Certificate into Azure Key Vault..."
# Import certificate into the Azure Key Vault for Safe Keeping.
Import-AzKeyVaultCertificate -VaultName $AzureKeyVaultName `
                            -Name "$ServicePrincipalName" `
                            -FilePath "$env:USERPROFILE\.secret\$ServicePrincipalName.pfx" `
                            -Password (ConvertTo-SecureString $CertificatePassword -AsPlainText -Force)# | Out-Null
#EndRegion

#Region Step 15 - Import into local certificate store.
Write-Host "importing into local Certificate store..."
# Import the PFX into the local windows certificate store.
certutil -f -user -p $CertificatePassword -importpfx "$env:USERPROFILE\.secret\$ServicePrincipalName.pfx" NoRoot #>$null 2>&1
#EndRegion

#Region Step 16 - Grab the cert from the local machine.

# Grab the cert from the local machine.
$cert = Get-ChildItem -path Cert:\CurrentUser\my | Where-Object {$PSitem.Thumbprint -eq $fingerprint}
#EndRegion

#Region Step 17 - Grab the Base Encoded String

# Get the Base encoded string.
$certValue = [System.Convert]::ToBase64String($cert.GetRawCertData())

#EndRegion

#Region Step 18 - Create the Azure AD Service Principal

Write-Host "Creating Azure AD Service Principal..."
# creating Azure AD service principal
$sp = New-AzADServicePrincipal -DisplayName $ServicePrincipalName `
                            -CertValue $certValue `
                            -EndDate $cert.NotAfter `
                            -StartDate $cert.NotBefore

#EndRegion

#Region Step 19 - Sleeping for 60 Seconds

Write-Verbose "Sleeping for 60 seconds as a workaround for a bug in AZ Module see - `"https://github.com/Azure/azure-powershell/issues/2286`""
Start-Sleep -Seconds 60
#EndRegion

#Region Step 20 - Grant the Role Assignment to the Resource Group

New-AzRoleAssignment -RoleDefinitionName Contributor -ServicePrincipalName $sp.ApplicationId -ResourceGroupName $ResourceGroupName #| Out-Null
Write-Verbose "Granted `"$ServicePrincipalName`" the Contributor permission for the Resource Group `"$ResourceGroupName`"."
#EndRegion

#Region Step 21 - Present values back to user
$SPNObjProps = @{
    ClientID = $($sp.ApplicationId.guid)
    TenantID = $($(get-azcontext).Tenant.id)
    SubscriptionID = $($(get-azcontext).subscription.id)
    Thumbprint = $($cert.thumbprint)
    ServicePrincipalName = $($sp.displayname)
    CertificatePassword = $CertificatePassword
    CertificatePath = "$env:userprofile\.secret\$ServicePrincipalName.pfx"
    PEMPath = "$env:USERPROFILE\.secret\$ServicePrincipalName.pem"
    Environment = $Environment
}
$SPNObj = New-Object -TypeName PSObject -Property $SPNObjProps
#Give the PSObject a custom Type name.
$SPNObj.PSObject.TypeNames.Insert(0,'MSH.MSHTools.MSHAzureSPN')

return $SPNObj
#EndRegion

#Region Step 22 - Set $VerbosePreference back to normal.
$VerbosePreference = 'SilentlyContinue'
#EndRegion

#Region Step 23 - If you need the PEM Content for an Azure Devops Service Connection
#                 then you can run the next command.
Get-Content "$env:USERPROFILE\.secret\$ServicePrincipalName.pem" | clip
#EndRegion

USE msdb
GO

EXEC dbo.sp_start_job N'DBA - audit' ;
GO

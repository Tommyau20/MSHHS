USE [msdb]
GO
GRANT EXECUTE ON [msdb].[dbo].[sp_notify_operator] TO [public]
GO
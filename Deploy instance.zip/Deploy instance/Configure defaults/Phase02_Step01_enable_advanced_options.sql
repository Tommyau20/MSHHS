EXEC master.sys.sp_configure 'show advanced options', 1
GO
RECONFIGURE
GO
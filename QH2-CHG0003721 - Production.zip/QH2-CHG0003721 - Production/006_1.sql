-- https://www.sqlshack.com/apply-sql-server-patches-or-cumulative-updates-in-sql-server-always-on-availability-groups/
-- https://blog.sqlauthority.com/2017/03/04/sql-server-apply-patch-alwayson-availability-group-configuration/


-- From the Availability Group primary node, change the availability group to “manual failover”.

USE [master]
GO
ALTER AVAILABILITY GROUP [SQLCL1MSPAGQCC1]
MODIFY REPLICA ON N'QCCATCL1DPRD01P\QCC_SQL_PRD001' WITH (FAILOVER_MODE = AUTOMATIC)
GO

USE [master]
GO
ALTER AVAILABILITY GROUP [SQLCL1MSPAGQCC1]
MODIFY REPLICA ON N'QCCATCL1DPRD02P\QCC_SQL_PRD002' WITH (FAILOVER_MODE = AUTOMATIC)
GO

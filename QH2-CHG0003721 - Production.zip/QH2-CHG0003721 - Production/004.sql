-- https://www.sqlshack.com/apply-sql-server-patches-or-cumulative-updates-in-sql-server-always-on-availability-groups/
-- https://blog.sqlauthority.com/2017/03/04/sql-server-apply-patch-alwayson-availability-group-configuration/


-- From the availability group secondary, resume data movement for the availability group
If (SELECT ARS.role_desc AS [AG_role_desc]
		FROM 	[master].sys.dm_hadr_availability_replica_cluster_states AS RCS INNER JOIN 
				[master].sys.dm_hadr_availability_replica_states AS ARS ON ARS.replica_id = RCS.replica_id
											WHERE RCS.replica_server_name = (SELECT SERVERPROPERTY('ComputerNamePhysicalNetBIOS'))) = 'SECONDARY'
	BEGIN
	DECLARE @DB_name varchar (150)
	DECLARE @SQL varchar(1000)
	DECLARE cursor_alter_DB CURSOR FOR  
	SELECT AGDatabases.database_name FROM sys.dm_hadr_availability_group_states States INNER JOIN
									master.sys.availability_groups Groups ON States.group_id = Groups.group_id INNER JOIN
											sys.availability_databases_cluster AGDatabases ON Groups.group_id = AGDatabases.group_id
												WHERE primary_replica != @@Servername
	OPEN cursor_alter_DB   
	FETCH NEXT FROM cursor_alter_DB INTO @DB_name 
	WHILE @@FETCH_STATUS = 0   
		BEGIN	
		SET @SQL = 'ALTER DATABASE ['+@DB_name+'] SET HADR RESUME'	
		PRINT @SQL
		EXEC (@SQL)  	 
		FETCH NEXT FROM cursor_alter_DB  INTO @DB_name   
		END
	CLOSE cursor_alter_DB   
	DEALLOCATE cursor_alter_DB
	END
ELSE
	BEGIN
	Print '*** STOP!!! *** - YOU ARE TRYING TO RUN THIS SCRIPT ON THE PRIMARY.'
	END

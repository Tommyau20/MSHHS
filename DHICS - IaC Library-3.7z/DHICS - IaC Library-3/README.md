This is the Metro South Health Digital Health and Informatics Cloud Services Infrastructure as Code Library!

(PHEW: - what a mouthful.)

![](./_assets/devops.png)
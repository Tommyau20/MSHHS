﻿function Get-RandomCharacters($length, $characters) { 
    $random = 1..$length | ForEach-Object { Get-Random -Maximum $characters.length } 
    $private:ofs = "" 
    return [String]$characters[$random]
}

# Set the RG variables.
$date = Get-Date -UFormat "%Y%m%d-%H%M%S"
$rgName = 'logsStorage-ause'
$rgLocation = 'australiasoutheast'
$rgTags = @{
    costCenterCode     = '2110214'
    criticality        = 'Low'
    resOwner           = 'Craig Dempsey'
    resOwnerDepartment = 'MSH Architecture & Security'
    resOwnerEmail      = 'craig.dempsey@health.qld.gov.au'
    resOwnerPhone      = '0731769082'
    resOwnerPosition   = 'Senior Technical Architect'
    deploymentMethod   = 'Arm Template'
    system             = 'CIDAS Connectivity'
}
$tempStorTags = @{
    costCenterCode     = '2110214'
    criticality        = 'Low'
    resOwner           = 'Craig Dempsey'
    resOwnerDepartment = 'MSH Architecture & Security'
    resOwnerEmail      = 'craig.dempsey@health.qld.gov.au'
    resOwnerPhone      = '0731769082'
    resOwnerPosition   = 'Senior Technical Architect'
    deploymentMethod   = 'Arm Template'
    system             = 'CIDAS Management'
    transient          = 'true'
}

#Set the Temporary Storage Account Variables.
$tempStorageAccountNamePrefix = 'mshcidastempstor'
$randomSuffix = Get-RandomCharacters -length 5 -characters 'abcdefghiklmnoprstuvwxyz'
$tempStorageAccountName = $tempStorageAccountNamePrefix + $randomSuffix
$tempStorageContainerName = 'templates'

#Set / Create Resource Group
$rg = New-AzResourceGroup -Name $rgName -Location $rgLocation -Tag $rgTags -Verbose -Force

# Create Temporary Deployment Storage Account
$tempStorAcc = New-AzStorageAccount `
    -Name $tempStorageAccountName `
    -ResourceGroupName $rg.resourceGroupName `
    -Location $rg.location `
    -Type Standard_LRS `
    -Tag $tempStorTags `
    -Verbose 

# Set Temporary Deployment Storage Account as current Storage Account
Set-AzCurrentStorageAccount `
    -ResourceGroupName $rg.ResourceGroupName `
    -Name $tempStorAcc.StorageAccountName

# Create new Storage Container
New-AzStorageContainer `
    -Name templates `
    -Permission Off

Get-ChildItem -File  -Recurse | Set-AzStorageBlobContent `
    -Container $tempStorageContainerName

#Get Artifacts Location
$_artifactsLocation = $tempStorAcc.Context.BlobEndPoint + $tempStorageContainerName

$_artifactsLocationSasToken = New-AzStorageContainerSASToken `
    -Container $tempStorageContainerName `
    -Context (get-azstoragecontainer -name templates).Context `
    -Permission r  `
    -ExpiryTime (get-Date).AddHours(5)

$_artifactsLocationSasToken = ConvertTo-SecureString -AsPlainText -Force ($_artifactsLocationSasToken)

# #Test the deployment first.
# $test = Test-AzResourceGroupDeployment `
#     -ResourceGroupName $rg.ResourceGroupName `
#     -TemplateFile '.\azuredeploy.json' `
#     -TemplateParameterFile '.\azuredeploy.parameters.json' `
#     -_artifactsLocation $_artifactsLocation `
#     -_artifactsLocationSasToken $_artifactsLocationSasToken `
#     -Verbose 

# if ($test) {
#     $test.Details.Message
#     Break
# }
# else {
#     Write-Verbose "Template has passed validation check, continuing with deployment..."
# }
#Finally actually deploy your templates and linked templates.
New-AzResourceGroupDeployment `
    -Name ("StorageAccountDeployment" + $date) `
    -ResourceGroupName $rg.ResourceGroupName `
    -TemplateFile '.\azuredeploy.json' `
    -TemplateParameterFile '.\azuredeploy.parameters.json' `
    -_artifactsLocation $_artifactsLocation `
    -_artifactsLocationSasToken $_artifactsLocationSasToken `
    -Verbose 

#Delete the Temporary Storage Account.
Remove-AzStorageAccount `
    -Name $tempStorageContainerName `
    -ResourceGroupName $rg.ResourceGroupName `
    -Force



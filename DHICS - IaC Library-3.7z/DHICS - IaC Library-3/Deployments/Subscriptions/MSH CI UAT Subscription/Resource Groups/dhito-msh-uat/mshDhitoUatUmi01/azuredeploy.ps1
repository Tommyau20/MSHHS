﻿$date = Get-Date -UFormat "%Y%m%d-%H%M%S"
$rg = 'dhito-uat-msh'
$rgTags = @{
    costCenterCode='2110214'
    criticality='Low'
    resOwner='Craig Dempsey'
    resOwnerDepartment='DHI Technology & Operations'
    resOwnerEmail='craig.dempsey@health.qld.gov.au'
    resOwnerPhone='0731769082'
    resOwnerPosition='Cloud Product Manager'
    system= 'DHITO Cloud Management'
    deploymentMethod= 'ARM Template'
}
New-AzResourceGroup -Name $rg -Location 'australiaeast' -Tag $rgTags -Verbose

New-AzResourceGroupDeployment `
    -Name ("userIdentityDeployment" + $date) `
    -ResourceGroupName $rg `
    -TemplateFile 'azuredeploy.json' `
    -TemplateParameterFile 'azuredeploy.parameters.json'



# Set-AzStorageServiceLoggingProperty `
#     -ServiceType Blob `
#     -Version 2.0 `
#     -RetentionDays 90 `
#     -LoggingOperations All `

################################################################
## Change your variables for the deployment HERE!!!!!!!!!!!!! ##
################################################################

# Set the RG variables.

$date = Get-Date -UFormat "%Y%m%d-%H%M%S"
$rgDeploymentName = 'parent-appServicePlan'
$rgName = 'dhito-uat-msh'
$rgLocation = 'australiaeast'
# Set tags for the Resource Group.
$rgTags = @{
    costCenterCode     = '2110214'
    criticality        = 'Low'
    resOwner           = 'Craig Dempsey'
    resOwnerDepartment = 'DHI Technology & Operations'
    resOwnerEmail      = 'craig.dempsey@health.qld.gov.au'
    resOwnerPhone      = '0731769082'
    resOwnerPosition   = 'Cloud Product Manager'
    deploymentMethod   = 'Arm Template'
    system             = 'DHITO Documentation'
}


################################################################
## You shouldn't have to really change anything below here!!! ##
################################################################
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#
################################################################

#Set / Create Resource Group
$rg = New-AzResourceGroup -Name $rgName -Location $rgLocation -Tag $rgTags -Verbose -Force

#Create the Template Spec

New-AzTemplateSpec `
    -Name webSpec `
    -Version "1.0.0.0" `
    -ResourceGroupName $rgName `
    -Location $rgLocation `
    -TemplateFile ".\azuredeploy.json" `
    -Verbose

$templateSpecId = (Get-AzTemplateSpec -ResourceGroupName $rgName -name webSpec -Version "1.0.0.0").Versions.Id

New-AzResourceGroupDeployment `
    -TemplateSpecId $templateSpecId `
    -ResourceGroupName $rgName `
    -TemplateParameterFile .\azuredeploy.parameters.json `
    -verbose `
    -DeploymentDebugLogLevel 'All'

#Delete the Temporary Storage Account.
Remove-AzStorageAccount `
    -Name $tempStorageAccountName `
    -ResourceGroupName $rg.ResourceGroupName `
    -Force `
    -Verbose



function Get-RandomCharacters($length, $characters) { 
    $random = 1..$length | ForEach-Object { Get-Random -Maximum $characters.length } 
    $private:ofs = "" 
    return [String]$characters[$random]
}

################################################################
## Change your variables for the deployment HERE!!!!!!!!!!!!! ##
################################################################

# Set the RG variables.

$date = Get-Date -UFormat "%Y%m%d-%H%M%S"
$rgDeploymentName = 'parent-appServicePlan'
$rgName = 'cd01'
$rgLocation = 'australiaeast'
# Set tags for the Resource Group.
$rgTags = @{
    costCenterCode     = '2110214'
    criticality        = 'Low'
    resOwner           = 'Craig Dempsey'
    resOwnerDepartment = 'MSH Architecture & Security'
    resOwnerEmail      = 'craig.dempsey@health.qld.gov.au'
    resOwnerPhone      = '0731769082'
    resOwnerPosition   = 'Senior Technical Architect'
    deploymentMethod   = 'Arm Template'
}

# Set the Tags for the temporary Storage Container.
$tempStorTags = @{
    costCenterCode     = '2110214'
    criticality        = 'Low'
    resOwner           = 'Craig Dempsey'
    resOwnerDepartment = 'MSH Architecture & Security'
    resOwnerEmail      = 'craig.dempsey@health.qld.gov.au'
    resOwnerPhone      = '0731769082'
    resOwnerPosition   = 'Senior Technical Architect'
    deploymentMethod   = 'Arm Template'
    system             = 'CIDAS Management'
    transient          = 'true'
}

################################################################
## You shouldn't have to really change anything below here!!! ##
################################################################
#!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!#
################################################################

#Set the Temporary Storage Account Variables.
$tempStorageAccountNamePrefix = 'mshcidastempstor'
$randomSuffix = Get-RandomCharacters -length 5 -characters '0123456789'
$tempStorageAccountName = $tempStorageAccountNamePrefix + $randomSuffix
$tempStorageContainerName = 'templates'

#Set / Create Resource Group
$rg = New-AzResourceGroup -Name $rgName -Location $rgLocation -Tag $rgTags -Verbose -Force

# Create Temporary Deployment Storage Account
$tempStorAcc = New-AzStorageAccount `
    -Name $tempStorageAccountName `
    -ResourceGroupName $rg.resourceGroupName `
    -Location $rg.location `
    -Type Standard_LRS `
    -Tag $tempStorTags `
    -Verbose 

# Set Temporary Deployment Storage Account as current Storage Account
Set-AzCurrentStorageAccount `
    -ResourceGroupName $rg.ResourceGroupName `
    -Name $tempStorAcc.StorageAccountName

# Create new Storage Container
New-AzStorageContainer `
    -Name templates `
    -Permission Off

Get-ChildItem -File  -Recurse | Set-AzStorageBlobContent `
    -Container $tempStorageContainerName

#Get Artifacts Location
$_artifactsLocation = $tempStorAcc.Context.BlobEndPoint + $tempStorageContainerName

#Setup the SasToken so we can feed that through to the deployment too. 
$_artifactsLocationSasToken = New-AzStorageContainerSASToken `
    -Container $tempStorageContainerName `
    -Context (get-azstoragecontainer -name templates).Context `
    -Permission r  `
    -ExpiryTime (get-Date).AddHours(5)

# The deployment takes SecureString type.
$_artifactsLocationSasToken = ConvertTo-SecureString -AsPlainText -Force ($_artifactsLocationSasToken)

# We feed the Template file and Template Parameters file in and then feed an 'Inline' parameters
# for _artifactsLocation and _artifactsLocationSasToken. The reason we do this is because the URL and SAS Token
# are generated AFTER we run this deployment script. In order to feed the Storage Account URL and Sas Token to the
# underlying deployments and child templates we need to add that on during runtime. That's what the Inline Parameters
# allow us to do.

New-AzResourceGroupDeployment `
    -Name $rgDeploymentName `
    -ResourceGroupName $rg.ResourceGroupName `
    -TemplateFile ".\azuredeploy.json" `
    -TemplateParameterFile ".\azuredeploy.parameters.json" `
    -_artifactsLocation $_artifactsLocation `
    -_artifactsLocationSasToken $_artifactsLocationSasToken `
    -Verbose 

#Delete the Temporary Storage Account.
Remove-AzStorageAccount `
    -Name $tempStorageAccountName `
    -ResourceGroupName $rg.ResourceGroupName `
    -Force `
    -Verbose



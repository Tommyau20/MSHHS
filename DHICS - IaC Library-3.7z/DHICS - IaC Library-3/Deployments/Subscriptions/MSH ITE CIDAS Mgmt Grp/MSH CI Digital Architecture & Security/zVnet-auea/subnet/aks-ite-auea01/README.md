# Subnet Deployment for Private Endpoint Subnet

This template is to be used to deploy an AKS Subnet and the following artifacts: - 

- Subnet
- NSG
- NSG Rules
- Route Table
- Routes
- NSG Flow Log

# How is this template used?

This template relies on having a vNet already deployed. 

# Permissions needed to deploy this NSG.

Network Contributor on the vNet

# Security Compliance

This template has been built to the MSH Azure Security Standard. Here are the benchmarks that are in compliance.

* [6.1.4 - Ensure that Network Security Group Flow Log retention period is 'greater than 90 days'](https://mshcidasdocfx01.azurewebsites.net/governance/azure_guideline/networking/6.1.4.html)
* [6.1.5 - Ensure that Network Watcher is 'Enabled'](https://mshcidasdocfx01.azurewebsites.net/governance/azure_guideline/networking/6.1.5.html)
* [6.2.1 - Ensure DENY rule is set above default AllowVnetInBound rule for all NSG’s.](https://mshcidasdocfx01.azurewebsites.net/governance/azure_guideline/networking/6.2.1.html)
* [6.2.3 - Ensure only approved UDR’s are in place on Subnets](https://mshcidasdocfx01.azurewebsites.net/governance/azure_guideline/networking/6.2.3.html)
* [6.2.4 - Ensure all Subnets have NSG’s attached](https://mshcidasdocfx01.azurewebsites.net/governance/azure_guideline/networking/6.2.4.html)

## Further Information
[**Metro South Health - Operational and Security Standards for Azure**](https://mshcidasdocfx01.azurewebsites.net/governance/azure_guideline/overview/index.html)  

# Set the RG variables.
$date = Get-Date -UFormat "%Y%m%d-%H%M%S"
$rgName = 'zPrivateEndpoints-ause'
$rgLocation = 'australiasoutheast'
$rgTags = @{
    costCenterCode     = '2110214'
    criticality        = 'Low'
    resOwner           = 'Craig Dempsey'
    resOwnerDepartment = 'MSH Architecture & Security'
    resOwnerEmail      = 'craig.dempsey@health.qld.gov.au'
    resOwnerPhone      = '0731769082'
    resOwnerPosition   = 'Senior Technical Architect'
    deploymentMethod   = 'Arm Template'
    system             = 'CIDAS Connectivity'
}
$tempStorTags = @{
    costCenterCode     = '2110214'
    criticality        = 'Low'
    resOwner           = 'Craig Dempsey'
    resOwnerDepartment = 'MSH Architecture & Security'
    resOwnerEmail      = 'craig.dempsey@health.qld.gov.au'
    resOwnerPhone      = '0731769082'
    resOwnerPosition   = 'Senior Technical Architect'
    deploymentMethod   = 'Arm Template'
    system             = 'CIDAS Management'
    transient          = 'true'
}

#Set / Create Resource Group
$rg = New-AzResourceGroup -Name $rgName -Location $rgLocation -Tag $rgTags -Verbose -Force


Very Simple Deployment of a Windows VM
https://github.com/Azure/azure-quickstart-templates/tree/master/101-vm-simple-windows

Virtual Machines ARM Template Reference
https://docs.microsoft.com/en-us/azure/templates/microsoft.compute/2019-12-01/virtualmachines
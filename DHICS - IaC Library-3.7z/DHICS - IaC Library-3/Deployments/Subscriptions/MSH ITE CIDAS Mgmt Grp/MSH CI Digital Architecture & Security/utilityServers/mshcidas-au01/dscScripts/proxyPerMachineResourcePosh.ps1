


# Import Binary from GUI User Settings
#$hkcuKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections"
#$dcs = (-join ( 
#(Get-ItemProperty -Path  $hkcuKey -Name DefaultConnectionSettings).DefaultConnectionSettings |
# Foreach-Object { ('{0:X2}' -f $_) + ',' })).TrimEnd(',')

# Or you can use this which is the equivalent of: - 
    # Proxy - proxy-icf.health.qld.gov.au:8088
    # Bypass - localhost;10.*.*.*;*.health.qld.gov.au

# This is the Binary Value which is equivalent of: Proxy - proxy-icf.health.qld.gov.au:8088 Bypass - localhost;10.*.*.*;*.health.qld.gov.au
$dcs = "46,00,00,00,03,00,00,00,0B,00,00,00,20,00,00,00,70,72,6F,78,79,2D,69,63,66,2E,68,65,61,6C,74,68,2E,71,6C,64,2E,67,6F,76,2E,61,75,3A,38,30,38,38,2E,00,00,00,6C,6F,63,61,6C,68,6F,73,74,3B,31,30,2E,2A,2E,2A,2E,2A,3B,2A,2E,68,65,61,6C,74,68,2E,71,6C,64,2E,67,6F,76,2E,61,75,3B,3C,6C,6F,63,61,6C,3E,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00"
# Convert to Hex Values
[byte[]]$dcshex = $dcs.Split(',') | % { "0x$_"}

$pMachineDefaultConnectionsKey = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Connections'
$pMachineDefaultConnectionsName = 'DefaultConnectionSettings'
$pMachineDefaultConnectionsType = 'Binary'
$pMachineDefaultConnectionsValue = $dcshex

if((Get-ItemProperty -Path $pMachineDefaultConnectionsKey).PSObject.Properties.Name -contains $pMachineDefaultConnectionsName){
    Remove-ItemProperty -Path $pMachineDefaultConnectionsKey -Name $pMachineDefaultConnectionsName -Force
}
else {
    New-ItemProperty -Path $pMachineDefaultConnectionsKey -Name $pMachineDefaultConnectionsName -PropertyType $pMachineDefaultConnectionsType -Value $pMachineDefaultConnectionsValue
}


#Import Binary from GUI User Settings
#$hkcuKey = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Internet Settings\Connections"
#$sls = (-join ( 
#(Get-ItemProperty -Path $hkcuKey -Name SavedLegacySettings).SavedLegacySettings |
# Foreach-Object { ('{0:X2}' -f $_) + ',' })).TrimEnd(',')

 # This is the Binary Value which is equivalent of: Proxy - proxy-icf.health.qld.gov.au:8088 Bypass - localhost;10.*.*.*;*.health.qld.gov.au
 $sls = "46,00,00,00,05,00,00,00,0B,00,00,00,20,00,00,00,70,72,6F,78,79,2D,69,63,66,2E,68,65,61,6C,74,68,2E,71,6C,64,2E,67,6F,76,2E,61,75,3A,38,30,38,38,2E,00,00,00,6C,6F,63,61,6C,68,6F,73,74,3B,31,30,2E,2A,2E,2A,2E,2A,3B,2A,2E,68,65,61,6C,74,68,2E,71,6C,64,2E,67,6F,76,2E,61,75,3B,3C,6C,6F,63,61,6C,3E,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00,00"
  # Convert to Hex Values
[byte[]]$slshex = $sls.Split(',') | % { "0x$_"}

$pMachineSavedLegacySettingsKey = 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Connections'
$pMachineSavedLegacySettingsName = 'DefaultConnectionSettings'
$pMachineSavedLegacySettingsType = 'Binary'
$pMachineSavedLegacySettingsValue = $slshex

if((Get-ItemProperty -Path $pMachineSavedLegacySettingsKey).PSObject.Properties.Name -contains $pMachineSavedLegacySettingsName){
    Remove-ItemProperty -Path $pMachineSavedLegacySettingsKey -Name $pMachineSavedLegacySettingsName -Force
}
else {
    New-ItemProperty -Path $pMachineSavedLegacySettingsKey -Name $pMachineSavedLegacySettingsName -PropertyType $pMachineSavedLegacySettingsType -Value $pMachineSavedLegacySettingsValue
}

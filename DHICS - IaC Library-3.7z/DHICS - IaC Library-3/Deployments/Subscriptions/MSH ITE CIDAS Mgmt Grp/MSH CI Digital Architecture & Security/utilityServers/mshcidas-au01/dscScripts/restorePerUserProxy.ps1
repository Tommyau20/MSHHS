Configuration ProxyPerUser {
    Registry ProxyPerMachinePolicy
    {
        Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Policies\Microsoft\Windows\CurrentVersion\Internet Settings'
        ValueName = 'ProxySettingsPerUser'
        Ensure = 'Absent'
        Force = $true
    }
    Registry ProxyPerMachineWinHttPSettings 
    {
        Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Connections'
        ValueName = 'WinHttPSettings'
        Ensure = 'Absent'
        Force = $true
    }
    Registry ProxyPerMachineDefaultConnectionSettings
    {
        Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Connections'
        ValueName = 'DefaultConnectionSettings'
        Ensure = 'Absent'
        Force = $true
    }
    Registry ProxyPerMachineSavedLegacySettings
    {
        Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings\Connections'
        ValueName = 'SavedLegacySettings'
        Ensure = 'Absent'
        Force = $true
    }

    Registry ProxyPerMachineProxyEnable
    {        
        Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings'
        ValueName = 'ProxyEnable'
        Ensure = 'Absent'
        Force = $true
    }
    Registry ProxyPerMachineProxyServer
    {        
        Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings'
        ValueName = 'ProxyServer'
        Ensure = 'Absent'
        Force = $true
    }
    Registry ProxyPerMachineProxyOverride
    {
        Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings'
        ValueName = 'ProxyOverride'
        Ensure = 'Absent'
        Force = $true
    }
    Registry ProxyPerMachineAutoConfigURL
    {
        Key = 'HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\Windows\CurrentVersion\Internet Settings'
        ValueName = 'AutoConfigURL'
        Ensure = 'Absent'
        Force = $true
    }
    Registry ProxyPerMachineLockAutoConfig
    {
        Key = 'HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Internet Explorer\Control Panel'
        ValueName = 'Autoconfig'
        Ensure = 'Absent'
        Force = $true
    }
    Registry ProxyPerMachineLockProxy
    {
        Key = 'HKEY_LOCAL_MACHINE\Software\Policies\Microsoft\Internet Explorer\Control Panel'
        ValueName = 'Proxy'
        Ensure = 'Absent'
        Force = $true
    }
}

ProxyPerUser 

Start-DscConfiguration -Path .\ProxyPerUser -Wait -Verbose

$ie = new-object -ComObject "InternetExplorer.Application"
$ie.Quit()

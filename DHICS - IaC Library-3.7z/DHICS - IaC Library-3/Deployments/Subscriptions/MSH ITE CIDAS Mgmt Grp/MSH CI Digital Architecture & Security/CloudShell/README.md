# Storage Account with Private Endpoint and Private Blob Container

This template deploys a Storage Account that aligns with MSH Operations & Security Benchmarks v0.5. 

It has the folllwing features: - 

## Networking
In this template, I have set the following by default: - 
-  QH Proxy in the Storage Firewall
   -   to allow traffic to come from the QH Network and go out the QH Internet Gateway to Azure.
- Private Endpoint
  - Setting this will force traffic over our Private Express Route.
  - An extra manual step is needed when setting Private Endpoint. You will have to manually log a job to the eHealth Cloud Services team to set an A Record in their Private DNS Zone for the Private Endpoint that you have created. Due to this limitation, no Private Endpoints in our subscription will be Private DNS Integrated.
- You shouldn't need both of these, choose one and disable the other.

## Advanced Threat Analytics
This template enables Advanced Theat Analytics on this storage account so that Azure Security Center can scan the Storage Account.

## Secure HTTP
This template enables Secure HTTP.

## Logging
This template enables Storage Diagnostic logging via a Powershell Script that runs via the Micrsoft.Resources/DeploymentScripts provider. 

## Private Blob Container
A private Blbo Container has been enabled in this template.

## User Managed Identity
A UMI is used as the authentication mechanism to run the Powershell Script via the Microsoft.Resrouces/DeploymentScripts provider.


## Further Information

**Persist files in Azure Cloud Shell**
https://docs.microsoft.com/en-us/azure/cloud-shell/persisting-shell-storage
**Fileshare Template Reference**
https://docs.microsoft.com/en-us/azure/templates/microsoft.storage/2019-06-01/storageaccounts/fileservices/shares

﻿$date = Get-Date -UFormat "%Y%m%d-%H%M%S"
$rg = 'armTemplates'
$rgTags = @{
    costCenterCode='2110214'
    criticality='Low'
    resOwner='Craig Dempsey'
    resOwnerDepartment='MSH Architecture & Security'
    resOwnerEmail='craig.dempsey@health.qld.gov.au'
    resOwnerPhone='0731769082'
    resOwnerPosition='Senior Technical Architect'
    deploymentMethod='Arm Template'
    system='CIDAS Management'
}
New-AzResourceGroup -Name $rg -Location 'australiaeast' -Tag $rgTags -Verbose 

New-AzResourceGroupDeployment `
    -Name ("KeyvaultDeployment" + $date) `
    -ResourceGroupName $rg `
    -TemplateFile 'azuredeploy.json' `
    -TemplateParameterFile 'azuredeploy.parameters.json' `
    -Verbose



# Base SQL MI Route Table and NSG Build and Attach

This template is to be used in conjunction with a MSH SQLMI deployment. This template isn't approved for release yet as I'm still working on it.

# Features of this Deployment

This deployment will deploy: - 

- Create an NSG
- Create a Route Table
- Include base Routes and NSG's that comply with SQL MI Network Intent Policy
- Include a set of approved MSH Firewall Rules for SQL MI
- Create an NSG flow log 

# How is this template used?

This template depends on the SQL MI being deployed. It will then add MSH approved NSG and Route table to the deployment over-riding the Microsoft generated NSG and Route Table. 

Anytime an NSG rule or a Route needs to be updated you would update this template and then re-deploy. 

This template also stores the NSG and RT in the same resource group as the Managed Instance. 

# Permissions needed to deploy this NSG.

Due to the fact that we attaching the NSG and the RT to a subnet in a virtual network, the account used to deploy this template needs to have at least have network contributor rights on the vnet. 

Contributor rights on the Resource Group where the MI is also needed.


# Security Compliance

This template has been built to the MSH Azure Security Standard. Here are the benchmarks that are in compliance.

* [6.1.4 - Ensure that Network Security Group Flow Log retention period is 'greater than 90 days'](https://mshcidasdocfx01.azurewebsites.net/governance/azure_guideline/networking/6.1.4.html)
* [6.1.5 - Ensure that Network Watcher is 'Enabled'](https://mshcidasdocfx01.azurewebsites.net/governance/azure_guideline/networking/6.1.5.html)
* [6.2.1 - Ensure DENY rule is set above default AllowVnetInBound rule for all NSG’s.](https://mshcidasdocfx01.azurewebsites.net/governance/azure_guideline/networking/6.2.1.html)
* [6.2.3 - Ensure only approved UDR’s are in place on Subnets](https://mshcidasdocfx01.azurewebsites.net/governance/azure_guideline/networking/6.2.3.html)
* [6.2.4 - Ensure all Subnets have NSG’s attached](https://mshcidasdocfx01.azurewebsites.net/governance/azure_guideline/networking/6.2.4.html)

## Further Information
[**Metro South Health - Operational and Security Standards for Azure**](https://mshcidasdocfx01.azurewebsites.net/governance/azure_guideline/overview/index.html)  

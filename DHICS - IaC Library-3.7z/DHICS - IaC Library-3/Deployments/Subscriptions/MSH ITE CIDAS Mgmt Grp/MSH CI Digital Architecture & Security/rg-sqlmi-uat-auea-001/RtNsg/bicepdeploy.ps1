﻿[CmdletBinding()]
param (
    [Parameter()]
    [switch]
    $whatIf
)


# Set the RG variables.
$date = Get-Date -UFormat "%Y%m%d-%H%M%S"
$rgName = 'rg-sqlmi-uat-auea-001'
$rgLocation = 'australiaeast'
$rgDeploymentName = 'NsgRtDeployment'
$templateSpecIdVersion = '1.0.0.0'
$templateSpecName = "nsgRtSpec"
$UserManagedInstanceObjectID = "05229bec-4073-4b86-a7e0-294490b67634"
$rgTags = @{
    costCenterCode     = '2110214'
    criticality        = 'Low'
    resOwner           = 'Craig Dempsey'
    resOwnerDepartment = 'DHI Technology & Operations'
    resOwnerEmail      = 'craig.dempsey@health.qld.gov.au'
    resOwnerPhone      = '0731769082'
    resOwnerPosition   = 'Cloud Product Manager'
    deploymentMethod   = 'Arm Template'
    system             = 'DHITO Management'
}

#########################################################
### You shouldn't have to change anything under here. ###
#########################################################

# Check working in the UAT Context.

$AzContext = Get-AzContext

if ($azcontext.Subscription.name -ne 'MSH CI Digital Architecture & Security'){
    Write-Host 'Not in UAT Enviroment, exiting.'
    Break
}

Function Install-ArmTtkModule {
    if(get-module -listavailable -name arm-ttk){
        write-host 'Arm TTK is installed'
    }
    else{
        import-module bitstransfer
        Start-BitsTransfer -Source 'https://aka.ms/arm-ttk-latest' -destination "$env:temp\arm-ttk.zip"
        Expand-Archive -Path "$env:temp\arm-ttk.zip" -DestinationPath "~\Documents\PowerShell\Modules\"
        Push-Location "~\Documents\Powershell\Modules\arm-ttk"
        Get-ChildItem *.ps1, *.psd1, *.ps1xml, *.psm1 -Recurse | Unblock-File
        Import-module arm-ttk
        Pop-Location
    }
}

Function Install-Bicep {
    if(bicep --version){
        Write-Host "Bicep is installed"
    }
    else{
        $installPath = "$env:USERPROFILE\.bicep"
        $installDir = New-Item -ItemType Directory -Path $installPath -Force
        $installDir.Attributes += 'Hidden'
        # Fetch the latest Bicep CLI binary
        (New-Object Net.WebClient).DownloadFile("https://github.com/Azure/bicep/releases/latest/download/bicep-win-x64.exe", "$installPath\bicep.exe")
        # Add bicep to your PATH
        $currentPath = (Get-Item -path "HKCU:\Environment" ).GetValue('Path', '', 'DoNotExpandEnvironmentNames')
        if (-not $currentPath.Contains("%USERPROFILE%\.bicep")) { setx PATH ($currentPath + ";%USERPROFILE%\.bicep") }
        if (-not $env:path.Contains($installPath)) { $env:path += ";$installPath" }
    }
}

Function Install-AzModule {
    if(get-module -ListAvailable Az){
        Write-Verbose 'Az Module is installed.'
    }
    else{
        Write-Verobse 'Installing AZ module now.'
        Install-Module -Name Az -Scope CurrentUser -Repository PSGallery -Force
    }
}


# Install the Azure Bicep executables.
Install-Bicep

# Install the Arm TTK Module if not installed.
Install-ArmTtkModule

# Install AZ Module
Install-AzModule

# Run the bicep build.
bicep build ./main.bicep

# Test-ARM Template against best practices.
Test-AzTemplate -TemplatePath '.\main.json'


    #Set / Create Resource Group
if(Get-AzResourceGroup -Name $rgName){
    Write-Verbose "Resource Group `'$rgName`' is already created."
}
else{
    New-AzResourceGroup -Name $rgName -Location $rgLocation -Tag $rgTags -Verbose -Force
}

#Create the Template Spec

New-AzTemplateSpec `
    -Name $templateSpecName `
    -Version $templateSpecIdVersion `
    -ResourceGroupName $rgName `
    -Location $rgLocation `
    -TemplateFile ".\main.json" `
    -Force `
    -Verbose

$templateSpecId = (Get-AzTemplateSpec -ResourceGroupName $rgName -name $templateSpecName -Version $templateSpecIdVersion).Versions.Id

# If Statement to carry out a "whatIf" if the parameter is specified.
if ($psboundparameters['whatIf']){
    New-AzResourceGroupDeployment `
    -Name $rgDeploymentName `
    -TemplateSpecId $templateSpecId `
    -ResourceGroupName $rgName `
    -TemplateParameterFile .\main.parameters.json `
    -Force `
    -verbose `
    -DeploymentDebugLogLevel 'All' `
    -WhatIf

    # Get-AzResourceGroupDeploymentWhatIfResult `
    # -DeploymentName ($rgDeploymentName + $date) `
    # -ResourceGroupName $rgName `
    # -TemplateFile '.\main.json' `
    # -TemplateParameterFile '.\main.parameters.json' `
    # -ResultFormat FullResourcePayloads

}
# If no "whatIf" then do the deployment
else {

# Grant temporary rights to the UMI on the RG to allow for Microsoft.Resources/DeploymentScripts script deployment as part of the deployment.

New-AzRoleAssignment `
    -RoleDefinitionName Contributor `
    -ObjectId $UserManagedInstanceObjectID `
    -ResourceGroupName $rgName

New-AzResourceGroupDeployment `
    -Name $rgDeploymentName `
    -TemplateSpecId $templateSpecId `
    -ResourceGroupName $rgName `
    -TemplateParameterFile .\main.parameters.json `
    -verbose `
    -DeploymentDebugLogLevel 'All'

# After the deployment has completed, remove the UMI rights.

Remove-AzRoleAssignment `
    -RoleDefinitionName Contributor `
    -ObjectId $UserManagedInstanceObjectID `
    -ResourceGroupName $rgName
}

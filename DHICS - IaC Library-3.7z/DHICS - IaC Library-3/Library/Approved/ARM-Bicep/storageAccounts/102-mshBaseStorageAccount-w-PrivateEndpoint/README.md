# Storage Account

This template deploys a Storage Account that aligns with MSH Operations & Security Benchmarks. 

It has the following features: - 

## Networking
In this template, I have set the following by default: - 
-  QH Proxy in the Storage Firewall
   -   to allow traffic to come from the QH Network and go out the QH Internet Gateway to Azure.

## Advanced Threat Analytics
This template enables Advanced Theat Analytics on this storage account so that Azure Security Center can scan the Storage Account.

## Secure HTTP
This template enables Secure HTTP.

## Logging
This template enables Storage Diagnostic logging via a Powershell Script that runs via the Micrsoft.Resources/DeploymentScripts provider. 

## Private Blob Container
A private Blob Container has been enabled in this template.

## User Managed Identity
A UMI is used as the authentication mechanism to run the Powershell Script via the Microsoft.Resources/DeploymentScripts provider. Make sure that contributor permissions have been granted to the UMI at the Resource Group Level to allow the DeploymentScript to be able to deploy the storage account and container instance to run the script.

## Alignment to MSH Operational & Security Standards
This template deploys a Storage Account that aligns with MSH Operations & Security Benchmarks. 

## Compliance
3.1.1 - Ensure that 'Secure transfer required' is set to 'Enabled'  
3.1.3 - Ensure that Storage logging is enabled for Queue service for read, write, and delete requests.  
3.1.6 - Ensure that 'Public access level' is set to Private for blob containers.  
3.1.7 - Ensure default network access rule for Sotrage Accounts is set to deny  
3.1.8 - Ensure 'Trusted Microsoft Services' is enabled for Storage Account access.  
3.2.1 - Ensure that Account Kind is set to Storage v2 (general purpsose)  
3.2.3 - Ensure Advanced Threat Protection is enabled.  
3.2.4 - Where Storage Accounts are used for logs, make sure the access policy is set to read only, immutable  
3.2.5 - Make sure read only immutable logs have a retention set to 90 days.  
3.2.6 - Make sure Blob soft delete is turned on and retention is set to 30 days.  
3.2.7 - Ensure that Sotrage logging is enabled for Blob, File, Table and Queue services and is set to version 2.0  

## Non-Compliance
3.2.2 - Ensure Private Endpoint is setup to allow connectivity from vNet where applicable. (This template doesn't deploy a Private Endpoint)

## Standards that can't be included in deployment template.  
3.1.2 - Ensure that storage account access keys are periodically regenerated.  
3.1.4 - Ensure that shared access signature tokens expire within an hour.  
3.1.5 - Ensure that shared access signature tokens are allowed only over https.  



## Further Information
[**Metro South Health - Operational and Security Standards for Azure**](https://mshcidasdocfx01.azurewebsites.net/governance/azure_guideline/overview/index.html)  
[**Microsoft.Storage storageAccounts template reference**](https://docs.microsoft.com/en-us/azure/templates/microsoft.storage/2019-06-01/storageaccounts)  
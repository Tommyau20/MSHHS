# Base Virtual Machine Build

This template is used for the base MSH VM builds. 

# Features of this Deployment

This deployment will deploy: - 

- A Network Interface (for the Virtual Machine)
- A Virtual Machine
- A storage account for diagnostic logs
- An ASG.

# Security Compliance

This template has been built to the MSH Azure Security Standard. Where compliance can't be done to the standard it will be documented below.

## Virtual Machine

### Compliant
---
**7.1.1** - Ensure Virutal Machines are utilizing Managed Disks  
   - All Virtual Machines use Managed disks as default  
**7.1.2** - Ensure that 'Data Disks' are encrypted  
   - All Data Disks are encrypted by SSE.  
**7.1.4** - Ensure that only approved extensions are installed  
   - The list of Approved VM extensions can be seen here: - [Approved VM Extensions](https://healthqld.sharepoint.com/:x:/r/teams/MSHHS-CollaborationPortal/TeamsArea/operationServices/Azure/Approved%20VM%20Extensions/Approved%20VM%20Extensions.xlsx?d=w974f29e3ae9944339db331d003bb1faa&csf=1&web=1&e=LZSLNy)  
**7.1.5** - Ensure that the lastest OS patches for all Virtual Machines are Applied  
   - Windows Server Images deployed from the Azure Marketplace contain the latest Important and Recommended updates whte were available at that time that the image was created.   
   - Further to that, as part of deployment the SCCM client is automatically installed on the VM as soon as it is discovered which gives Anti-Virus and Windows Update patching support.  
**7.1.6** - Ensure that the endpoint protection for all Virtual machine is Installed  
   - As part of deployment the SCCM client is automatically installed on the VM as soon as it is discovered which gives Anti-Virus and Windows Update patching support.  
**7.1.7** - Ensure that VHD's are encrypted  
   - All Virtual Machines are encrypted by SEE.  
**7.2.1** - Ensure no Public IP is associated to any VM  
   - No public IP is associated with this VM template.  
**7.2.4** - Ensure QH Tenable Nessus is set to Scan Virtual Machine  
   - Tenable automatically scans Azure vNet ranges.  
   - A credentialled scan will take place if the VM is domain joined.  

### Non-Compliant  
---
**7.1.3** - Ensure that 'Unattached disks' are encrypted with CMK  
   - Customer Managed Keys are currently not used in Metro South.  
**7.2.5** - Ensure Virtual machine vulnerabilities are remediated  
   - No way to automate this as part of this deployment.  
   - We should take an approach to shift left by putting security configurations in to deployment pipelines, Azure Polices, Group Policies or SCCM Task Sequences.  
**7.2.6** - Ensure that Security Recommendations for VM are remediated  
   - No way to automate this as part fo this deployment.  
   - We should take an approach to shift left by putting security configurations in to deployment pipelines, Azure Polices, Group Policies or SCCM Task Sequences.  
**7.2.7** - Ensure Virtual Machine is compliant with all associated Security Policies  
   - No way to automate this as part fo this deployment.  
   - We should take an approach to shift left by putting security configurations in to deployment pipelines, Azure Polices, Group Policies or SCCM Task Sequences.  
**7.2.11** - All internet bound traffic from the VM must use QH Proxy  
   - Proxy is configured via Group Policy.  


### To do  
---
**7.2.2** - Ensure Azure VM is joined to PA-Health Domain.  
   - I have created [Work Item](https://dev.azure.com/MSHHS-DHI-Cloud-Services/DHICS%20-%20IaC%20Library/_workitems/edit/39/) to do this.  
**7.2.3** - Ensure Azure VM is managed by MSHHS SCCM instance  
   - I have created [Work Item](https://dev.azure.com/MSHHS-DHI-Cloud-Services/DHICS%20-%20IaC%20Library/_workitems/edit/40) to do this.  
**7.2.8** - Ensure Guest Level monitoring is enabled for the Virtual Machine.  
   - I have created [Work Item](https://dev.azure.com/MSHHS-DHI-Cloud-Services/DHICS%20-%20IaC%20Library/_workitems/edit/41) to do this.  
**7.2.9** - Ensure Basic Logging is enabled for the Virtual Machine  
   - I have created [Work Item](https://dev.azure.com/MSHHS-DHI-Cloud-Services/DHICS%20-%20IaC%20Library/_workitems/edit/42/) to do this.  
**7.2.10** - Ensure Diagnostic Agent is configured for the Virtual Machine  
   - I have created [Work Item](https://dev.azure.com/MSHHS-DHI-Cloud-Services/DHICS%20-%20IaC%20Library/_workitems/edit/43/) to do this.  

# Storage Account

This template deploys a Storage Account that aligns with MSH Operations & Security Benchmarks. 

It has the following features: - 

## Networking
In this template, I have set the following by default: - 
-  QH Proxy in the Storage Firewall
   -   to allow traffic to come from the QH Network and go out the QH Internet Gateway to Azure.

## Advanced Threat Analytics
This template enables Advanced Theat Analytics on this storage account so that Azure Security Center can scan the Storage Account.

## Secure HTTP
This template enables Secure HTTP.

## Logging
This template enables Storage Diagnostic logging via a Powershell Script that runs via the Micrsoft.Resources/DeploymentScripts provider. 

## Private Blob Container
A private Blob Container has been enabled in this template.

## User Managed Identity
A UMI is used as the authentication mechanism to run the Powershell Script via the Microsoft.Resources/DeploymentScripts provider. Make sure that contributor permissions have been granted to the UMI at the Resource Group Level to allow the DeploymentScript to be able to deploy the storage account and container instance to run the script.

## Alignment to MSH Operational & Security Standards
This template deploys a Storage Account that aligns with MSH Operations & Security Benchmarks. 

## Compliance
3.1.1 - Ensure that 'Secure transfer required' is set to 'Enabled'  
3.1.3 - Ensure that Storage logging is enabled for Queue service for read, write, and delete requests.  
3.1.6 - Ensure that 'Public access level' is set to Private for blob containers.  
3.1.7 - Ensure default network access rule for Sotrage Accounts is set to deny  
3.1.8 - Ensure 'Trusted Microsoft Services' is enabled for Storage Account access.  
3.2.1 - Ensure that Account Kind is set to Storage v2 (general purpsose)  
3.2.3 - Ensure Advanced Threat Protection is enabled.  
3.2.4 - Where Storage Accounts are used for logs, make sure the access policy is set to read only, immutable  
3.2.5 - Make sure read only immutable logs have a retention set to 90 days.  
3.2.6 - Make sure Blob soft delete is turned on and retention is set to 30 days.  
3.2.7 - Ensure that Sotrage logging is enabled for Blob, File, Table and Queue services and is set to version 2.0  

## Non-Compliance
3.2.2 - Ensure Private Endpoint is setup to allow connectivity from vNet where applicable. (This template doesn't deploy a Private Endpoint)

## Standards that can't be included in deployment template.  
3.1.2 - Ensure that storage account access keys are periodically regenerated.  
3.1.4 - Ensure that shared access signature tokens expire within an hour.  
3.1.5 - Ensure that shared access signature tokens are allowed only over https.  

## Further Information
[**Metro South Health - Operational and Security Standards for Azure**](https://mshcidasdocfx01.azurewebsites.net/governance/azure_guideline/overview/index.html)  
[**Microsoft.Storage storageAccounts template reference**](https://docs.microsoft.com/en-us/azure/templates/microsoft.storage/2019-06-01/storageaccounts)  
﻿$computers = Get-content -path ".\computers.txt"

foreach ($computer in $computers) {
    Resolve-DnsName -name $computer -Server 10.21.32.122 -DnsOnly
}
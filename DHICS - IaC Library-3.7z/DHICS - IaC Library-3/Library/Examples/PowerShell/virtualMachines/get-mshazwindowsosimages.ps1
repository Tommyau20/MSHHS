﻿$locName = "australiaeast"
Get-AzVMImagePublisher -Location $locName |Select PublisherName

$pubName="MicrosoftWindowsServer"
Get-AzVMImageOffer -Location $locName -PublisherName $pubName | Select Offer

$offerName="WindowsServer"
Get-AzVMImageSku -Location $locName -PublisherName $pubName -Offer $offerName | Select Skus

$skuName="2022-datacenter"
Get-AzVMImage -Location $locName -PublisherName $pubName -Offer $offerName -Skus $skuname
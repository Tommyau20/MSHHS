# https://docs.microsoft.com/en-us/azure/virtual-machines/extensions/features-windows#discover-vm-extensions

Get-AzVmImagePublisher -Location "AustraliaEast"

Get-AzVMExtensionImageType -Location "AustraliaEast" -PublisherName 'Microsoft.Compute'

Get-AzVMExtensionImage -Location "AustraliaEast" -PublisherName 'Microsoft.Compute' -Type CustomScriptExtension
New-MSHAZSPN -ServicePrincipalName 'mshhs-az-ite-azdevops-azpolicy-contrib-spn-01' `
-CertCommonName "MSH ITE Environment Azure Devops Azure Policy Pipeline SPN" `
-AzureKeyVaultName "mshcidaskv01" `
-Environment "Development" `
-CertCountry "AU" `
-CertState "QLD" `
-CertCity "WOOLOONGABBA" `
-CertOrganization "QUEENSLAND HEALTH" `
-CertOrganizationalUnit "METRO SOUTH HEALTH" `
-Verbose
# -CertificatePassphrase "Valentich99Bass" ` // This is fine for testing, but for prod, put the passphrase and password in at the command line. 
# -CertificatePassword "BrownMountainLights32410" ` // DONT COMMIT YOUR SECRETS TO SOURCE CODE REPOSITORY!!!! DON'T BE THAT GUY!

#Generate PEM from PFX
openssl pkcs12 -in C:\Users\dempcraig\.secret\mshhs-az-ite-azdevops-azpolicy-contrib-spn-01.pfx -out C:\Users\dempcraig\.secret\mshhs-az-ite-azdevops-azpolicy-contrib-spn-01.pem -nodes

#Grant the permissions of the spn to the Managment Group
New-AzRoleAssignment -ObjectId (Get-AZADServicePrincipal -applicationid "9a05e88d-158f-4c35-ae23-771df86a4273").id -roledefinitionName 'Resource Policy Contributor'


$obj = Get-AzSecuritySetting | where-object 'Name' -eq 'MCAS'
$obj.Enabled
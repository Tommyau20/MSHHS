New-AzPolicyDefinition `
    -Name "Ensure-Std-Pricing-Tier-is-Enabled" `
    -DisplayName "Ensure-Std-Pricing-Tier-is-Enabled" `
    -Description "The standard pricing tier enables threat detection, providing threat intelligence, anomaly detection, and behaviour analytics in the Azure Security Centre. 2.1.1,2.1.2,2.1.3,2.1.4,2.2.3" `
    -Policy './policy.rules.json' `
    -Parameter './policy.parameters.json' `
    -Mode 'All' `
    -ManagementGroupName 'msh-ite-das-mgmt-grp' `
    -Metadata '{"category":"Security Center","version":"1.0.0", "MSH-Standard":"2.1.1,2.1.2,2.1.3,2.1.4,2.2.3"}' `
    -Verbose
﻿$date = Get-Date -UFormat "%Y%m%d-%H%M%S"
$rg = 'key-vault-test01'
New-AzResourceGroup -Name $rg -Location 'australiaeast'

New-AzResourceGroupDeployment `
    -Name ("testKeyvaultDeployment" + $date) `
    -ResourceGroupName $rg `
    -TemplateFile 'azuredeploy.json' `
    -TemplateParameterFile 'azuredeploy.parameters.json' `
    -Verbose



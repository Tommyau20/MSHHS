# Key Vault with Logging turned on and Private Endpoint setup.
This template will create a Key Vault with Audit Event Log being sent to Log Analytics workspace. It will also enable a Private Endpoint on the Key Vault also.

# MSH - Operational & Security Standards
## Compliance
9.2.3 - Audit event logs are being sent to Log Analytics.
9.1.3 - Ensure the key vault is recoverable.
9.2.2 - Private Endpoint created.

## Non-Compliance
9.2.1 - Ensure no external IP's are listed in Key Vault (Proxy Ip's are listed initially until Private Endpoints DNS is set by eHealth Cloud Services. Once DNS is registered, you can delete the IP's in the Key Vault Firewall.)
9.2.2 - Private endpoints aren't in use yet.

## Standards that can't be included in deployment template.
9.1.1 - Ensure that the expiration date is set on all keys. (No keys are created in this template.)
9.1.2 - Ensure that the expiration date is set on all secrets. (No secretes are created in this template.)

## Other Features

- This template also utilizes Linked Templates to modularize the code. For more information on this technique please read: - https://docs.microsoft.com/en-us/azure/azure-resource-manager/templates/linked-templates
- This template also employs a technique of using Parameter Objects to try and keep the code tidier and follow the best practice of setting the parameters at the parent template level. For more information on this technique please read the following documentation: - https://docs.microsoft.com/en-us/azure/architecture/building-blocks/extending-templates/objects-as-parameters

param(
    $ResourceGroupName,
    $StorageAccountName,
    $subscriptionid
)
Set-AzContext -Subscription $subscriptionid
$StorageAccount = Get-AzStorageAccount -ResourceGroupName $ResourceGroupName -Name $StorageAccountName -Verbose
$Key = (Get-AzStorageAccountKey -ResourceGroupName $ResourceGroupName -Name $StorageAccount.StorageAccountName -Verbose)[0].Value
$Context = New-AzStorageContext -StorageAccountName $StorageAccount.StorageAccountName -StorageAccountKey $key -Verbose
Set-AzStorageServiceLoggingProperty -Context $Context -ServiceType Blob -LoggingOperations All -RetentionDays 90 -Version '2.0' -Verbose
Set-AzStorageServiceLoggingProperty -Context $Context -ServiceType Queue -LoggingOperations All -RetentionDays 90 -Version '2.0' -Verbose
Set-AzStorageServiceLoggingProperty -Context $Context -ServiceType Table -LoggingOperations All -RetentionDays 90 -Verbose
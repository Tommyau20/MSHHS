# Virtual Machine deployment compliant with MSH Operational & Security Standard
This template will deploy a singular VM with the following resources: -
- An Application Group
- A Storage Account for Diagnostic Settings
- A Private Endpoint for the Storage Account
- A Network Interface for the Virtual Machine.
- A custom Script deployment to configure the Diagnostic Settings.


## Other Features

- This template also utilizes Linked Templates to modularize the code. For more information on this technique please read: - https://docs.microsoft.com/en-us/azure/azure-resource-manager/templates/linked-templates
- This template also employs a technique of using Parameter Objects to try and keep the code tidier and follow the best practice of setting the parameters at the parent template level. For more information on this technique please read the following documentation: - https://docs.microsoft.com/en-us/azure/architecture/building-blocks/extending-templates/objects-as-parameters

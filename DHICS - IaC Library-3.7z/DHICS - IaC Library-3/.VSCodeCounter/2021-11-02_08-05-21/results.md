# Summary

Date : 2021-11-02 08:05:21

Directory c:\Users\dempcraig\projects\DHICS - IaC Library\Deployments\Subscriptions\MSH ITE CIDAS Mgmt Grp\MSH CI Digital Architecture & Security\rg-sqlmi-uat-auea-001\SqlManagedInstance

Total : 15 files,  2536 codes, 36 comments, 113 blanks, all 2685 lines

[details](details.md)

## Languages
| language | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| JSON | 4 | 1,385 | 0 | 1 | 1,386 |
| Bicep | 8 | 1,006 | 12 | 67 | 1,085 |
| PowerShell | 2 | 130 | 24 | 29 | 183 |
| Markdown | 1 | 15 | 0 | 16 | 31 |

## Directories
| path | files | code | comment | blank | total |
| :--- | ---: | ---: | ---: | ---: | ---: |
| . | 15 | 2,536 | 36 | 113 | 2,685 |
| archive | 2 | 160 | 0 | 0 | 160 |
| bicepmodules | 7 | 879 | 0 | 29 | 908 |

[details](details.md)
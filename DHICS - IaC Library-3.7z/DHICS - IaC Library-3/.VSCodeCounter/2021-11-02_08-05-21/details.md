# Details

Date : 2021-11-02 08:05:21

Directory c:\Users\dempcraig\projects\DHICS - IaC Library\Deployments\Subscriptions\MSH ITE CIDAS Mgmt Grp\MSH CI Digital Architecture & Security\rg-sqlmi-uat-auea-001\SqlManagedInstance

Total : 15 files,  2536 codes, 36 comments, 113 blanks, all 2685 lines

[summary](results.md)

## Files
| filename | language | code | comment | blank | total |
| :--- | :--- | ---: | ---: | ---: | ---: |
| [Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/README.md](/Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/README.md) | Markdown | 15 | 0 | 16 | 31 |
| [Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/archive/parameters.json](/Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/archive/parameters.json) | JSON | 15 | 0 | 0 | 15 |
| [Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/archive/template.json](/Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/archive/template.json) | JSON | 145 | 0 | 0 | 145 |
| [Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/bicepdeploy.ps1](/Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/bicepdeploy.ps1) | PowerShell | 114 | 24 | 29 | 167 |
| [Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/bicepmodules/nsg.bicep](/Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/bicepmodules/nsg.bicep) | Bicep | 393 | 0 | 4 | 397 |
| [Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/bicepmodules/nsgFlowLog.bicep](/Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/bicepmodules/nsgFlowLog.bicep) | Bicep | 25 | 0 | 2 | 27 |
| [Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/bicepmodules/routeTable.bicep](/Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/bicepmodules/routeTable.bicep) | Bicep | 261 | 0 | 4 | 265 |
| [Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/bicepmodules/sqlmi.bicep](/Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/bicepmodules/sqlmi.bicep) | Bicep | 30 | 0 | 2 | 32 |
| [Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/bicepmodules/storAccPrivateEndpoint.bicep](/Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/bicepmodules/storAccPrivateEndpoint.bicep) | Bicep | 23 | 0 | 3 | 26 |
| [Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/bicepmodules/storageAccount.bicep](/Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/bicepmodules/storageAccount.bicep) | Bicep | 125 | 0 | 11 | 136 |
| [Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/bicepmodules/subnet.bicep](/Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/bicepmodules/subnet.bicep) | Bicep | 22 | 0 | 3 | 25 |
| [Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/debug.ps1](/Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/debug.ps1) | PowerShell | 16 | 0 | 0 | 16 |
| [Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/main.bicep](/Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/main.bicep) | Bicep | 127 | 12 | 38 | 177 |
| [Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/main.json](/Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/main.json) | JSON | 1,144 | 0 | 0 | 1,144 |
| [Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/main.parameters.json](/Deployments/Subscriptions/MSH ITE CIDAS Mgmt Grp/MSH CI Digital Architecture & Security/rg-sqlmi-uat-auea-001/SqlManagedInstance/main.parameters.json) | JSON | 81 | 0 | 1 | 82 |

[summary](results.md)